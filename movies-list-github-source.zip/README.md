# Movies List — Shimu Akter Cinematic Universe & Discovery Portal

Discover trending movies, new releases, popular videos and the curated 20-film Shimu Akter collection on Movies List. Includes custom real-time theme customization studio, instant filtering, and responsive player HUD.

---

## 🚀 Netlify Deployment Guide (সহজে Netlify-তে হোস্ট করার নিয়ম)

### Method 1: Instant Drag & Drop (সবচেয়ে সহজ উপায়)
1. Download or extract the `movies-list-netlify-deploy.zip` file.
2. Log in to [Netlify](https://app.netlify.com/).
3. Go to the **Sites** tab and find **"Want to deploy a new site without connecting to Git? Drag and drop your site output folder here"**.
4. Drag and drop the unzipped `dist` folder (or upload the files directly).
5. Your website will be live worldwide in seconds with free SSL (`https://your-site.netlify.app`)!

### Method 2: Deploy with GitHub (Continuous Deployment)
1. Push this project source code to your GitHub repository (see GitHub steps below).
2. Go to [Netlify](https://app.netlify.com/) -> **Add new site** -> **Import an existing project**.
3. Select **GitHub** and choose your repository.
4. Settings will be auto-detected:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. Click **Deploy Site**. Every time you push changes to GitHub, Netlify will automatically build and update your site.

---

## 🐙 GitHub Upload Guide (GitHub-এ আপলোড করার নিয়ম)

Extract `movies-list-github-source.zip` and run the following terminal commands:

```bash
# 1. Initialize git repository
git init

# 2. Add all files
git add .

# 3. Commit your files
git commit -m "Initial commit: Movies List Portal"

# 4. Set main branch
git branch -M main

# 5. Connect to your GitHub repository (Replace with your repository URL)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git

# 6. Push to GitHub
git push -u origin main
```

---

## 💻 Local Development (লোকাল কম্পিউটারে রান করার নিয়ম)

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

---

## ✨ Features
- **Cinematic Discovery Feed**: 20+ feature movies and video highlights.
- **Theme Studio**: Custom real-time theme switcher and theme creator with live preview and browser persistence (`localStorage`).
- **Interactive Player HUD**: 4K 60fps streaming player simulation with live playback timecode, scrubber, and dual servers.
- **Full Responsive Design**: Optimized for smartphones, tablets, laptops, and ultra-wide screens.
