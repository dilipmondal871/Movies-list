export interface Movie {
  id: string;
  title: string;
  year: string;
  duration: string;
  genre: string;
  categories: string[];
  rating: string;
  quality: string;
  poster: string;
  description: string;
  director: string;
  cast: string;
  offerUrl: string;
}

export interface VideoItem {
  id: string;
  title: string;
  duration: string;
  channel: string;
  avatar: string;
  views: string;
  timeAgo: string;
  thumbnail: string;
  description: string;
  offerUrl: string;
}

export const OFFER_LINK_1 = "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57";
export const OFFER_LINK_2 = "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57";

export const CATEGORIES = [
  "All",
  "Movies",
  "Trending",
  "Romance",
  "Adventure",
  "Drama",
  "Action",
  "Sci-Fi",
  "Thriller",
  "Crime",
  "Documentary"
];

export const POPULAR_CATEGORIES = [
  { name: "Action", count: "128 videos", image: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80" },
  { name: "Adventure", count: "94 videos", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=600&q=80" },
  { name: "Sci-Fi", count: "112 videos", image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80" },
  { name: "Romance", count: "64 videos", image: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=600&q=80" },
  { name: "Thriller", count: "86 videos", image: "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=600&q=80" },
  { name: "Drama", count: "105 videos", image: "https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=600&q=80" },
  { name: "Crime", count: "52 videos", image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80" },
  { name: "Documentary", count: "41 videos", image: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=600&q=80" }
];

export const FAQ_LIST = [
  {
    question: "What is Movies List?",
    answer: "Movies List is an independent movie and video discovery portal designed to help film lovers discover trending movies, explore curated genre collections, review ratings, and find entertainment recommendations in one modern interface."
  },
  {
    question: "Is Movies List available on mobile?",
    answer: "Yes, Movies List is fully responsive and optimized for all screen sizes including iOS and Android smartphones, tablets, laptops, and wide desktop displays without requiring any app download."
  },
  {
    question: "Can I browse movies by genre?",
    answer: "Absolutely. You can use our interactive category navigation bar at the top of the feed or click on any of our Popular Category cards to instantly filter titles by Action, Adventure, Sci-Fi, Thriller, Drama, Romance, and more."
  },
  {
    question: "How do I start watching?",
    answer: "Simply click on any movie card to inspect details and metadata, or click action buttons such as 'Watch Now', 'Continue to Watch', or 'Get Started' to navigate to our recommended viewing partners and sponsored options."
  },
  {
    question: "Are all movies available for free?",
    answer: "Availability and viewing terms vary depending on the destination provider, licensing rules, regional catalog rights, and promotional terms. We do not claim or guarantee that every piece of media is free forever."
  },
  {
    question: "Why was I redirected to another website?",
    answer: "Some buttons may direct users to third-party promotional or sponsored offers. Availability and requirements are determined by the destination website. Movies List acts as a discovery portal and connects viewers with external platforms."
  }
];

export const MOVIES: Movie[] = [
  {
    "id": "the-king-of-the-dark-sea",
    "title": "The King of the Dark Sea",
    "year": "2026",
    "duration": "2h 24m",
    "genre": "Romance",
    "categories": [
      "All",
      "Movies",
      "Romance",
      "Adventure",
      "Trending"
    ],
    "rating": "9.6",
    "quality": "4K UHD",
    "poster": "/images/the_king_of_the_dark_sea.jpg",
    "description": "A Shimu Akter Film. 'Some bonds are not written in destiny, but in hearts...' An epic romantic tale of a legendary maritime king in dark armor and his beloved soulmate amidst stormy seas and an ancient island fortress.",
    "director": "Shimu Akter",
    "cast": "Shimu Akter, Elena Rostova, Marcus Thorne, David Vance",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "the-hidden-truth",
    "title": "The Hidden Truth",
    "year": "2026",
    "duration": "2h 12m",
    "genre": "Thriller",
    "categories": [
      "All",
      "Movies",
      "Thriller",
      "Drama",
      "Trending"
    ],
    "rating": "9.5",
    "quality": "4K UHD",
    "poster": "/images/the_hidden_truth.jpg",
    "description": "A Shimu Akter Film. 'Some truths should never be found...' An intense, pulse-pounding mystery following two lovers trapped in a dangerous labyrinth of secret conspiracies, rain-drenched streets, and unsolved investigations.",
    "director": "Shimu Akter",
    "cast": "Elena Rostova, David Vance, Shimu Akter, Kenji Sato",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "the-dark-sea-king",
    "title": "The Dark Sea King",
    "year": "2026",
    "duration": "2h 19m",
    "genre": "Adventure",
    "categories": [
      "All",
      "Movies",
      "Adventure",
      "Drama",
      "Trending"
    ],
    "rating": "9.4",
    "quality": "4K UHD",
    "poster": "/images/the_dark_sea_king.jpg",
    "description": "A Shimu Akter Masterpiece. 'A King of the Dark Sea / A Simple Girl with a Big Heart \u2014 Love \u2022 Power \u2022 Destiny.' When high seas conflict threatens their realm, royal swordplay and unfaltering loyalty become their ultimate shield.",
    "director": "Shimu Akter",
    "cast": "Shimu Akter, Julian Mercer, Elena Rostova",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "the-last-promise",
    "title": "The Last Promise",
    "year": "2026",
    "duration": "2h 08m",
    "genre": "Drama",
    "categories": [
      "All",
      "Movies",
      "Drama",
      "Romance",
      "Trending"
    ],
    "rating": "9.5",
    "quality": "4K UHD",
    "poster": "/images/the_last_promise.jpg",
    "description": "A Shimu Akter Film. 'Some love stories are written by fate...' Against a glorious coastal sunset and an ancient cliffside lighthouse, two passionate souls forge a vow that defies time, family honor, and oceans.",
    "director": "Shimu Akter",
    "cast": "Elena Rostova, David Vance, Shimu Akter",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "the-royal-heart",
    "title": "The Royal Heart",
    "year": "2026",
    "duration": "2h 18m",
    "genre": "Drama",
    "categories": [
      "All",
      "Movies",
      "Drama",
      "Trending"
    ],
    "rating": "9.4",
    "quality": "4K UHD",
    "poster": "/images/the_king_of_the_dark_sea.jpg",
    "description": "The crown jewel of director Shimu Akter's 20-film cinematic universe. A grand, heart-stirring romance unfolding across opulent royal halls, forbidden loyalty, and sacrifice.",
    "director": "Shimu Akter",
    "cast": "Elena Rostova, David Vance, Shimu Akter, Julian Mercer",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "last-horizon",
    "title": "The Last Horizon",
    "year": "2026",
    "duration": "2h 14m",
    "genre": "Sci-Fi",
    "categories": [
      "All",
      "Movies",
      "Sci-Fi",
      "Trending"
    ],
    "rating": "8.7",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80",
    "description": "When an experimental deep-space warp vessel drifts into an uncharted solar sector, the crew confronts an ancient stellar phenomenon that reshapes perception and physics itself.",
    "director": "Elena Vance",
    "cast": "Marcus Thorne, Linnea Sol, David Karras",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "midnight-run",
    "title": "Midnight Run",
    "year": "2026",
    "duration": "1h 52m",
    "genre": "Action",
    "categories": [
      "All",
      "Movies",
      "Action",
      "Thriller",
      "Trending"
    ],
    "rating": "8.4",
    "quality": "HD",
    "poster": "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=800&q=80",
    "description": "A high-stakes metropolitan courier carries an encrypted biometric key through rain-slicked city streets while dodging two ruthless private security cartels.",
    "director": "Garrick Reed",
    "cast": "Jonah Hayes, Sarah Drake, Kenji Sato",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "ocean-of-stars",
    "title": "Ocean of Stars",
    "year": "2025",
    "duration": "2h 06m",
    "genre": "Adventure",
    "categories": [
      "All",
      "Movies",
      "Adventure",
      "Sci-Fi",
      "Trending"
    ],
    "rating": "8.8",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80",
    "description": "A breathtaking aquatic odyssey across a remote oceanic exoplanet, where bioluminescent marine leviathans hold the genetic code to rejuvenate a dying Earth.",
    "director": "Marina Dupont",
    "cast": "Aria Sterling, Tarek Mansour, Chloe Bennett",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "shadow-city",
    "title": "Shadow City",
    "year": "2026",
    "duration": "1h 48m",
    "genre": "Thriller",
    "categories": [
      "All",
      "Movies",
      "Thriller",
      "Trending"
    ],
    "rating": "8.3",
    "quality": "HD",
    "poster": "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=800&q=80",
    "description": "An investigative reporter uncovers a clandestine network orchestrating blackout algorithms across an entire coastal megalopolis.",
    "director": "Julian Croft",
    "cast": "Damian Cross, Eva Mendez-Hall, Victor Vance",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "beyond-tomorrow",
    "title": "Beyond Tomorrow",
    "year": "2025",
    "duration": "2h 01m",
    "genre": "Drama",
    "categories": [
      "All",
      "Movies",
      "Drama",
      "Trending"
    ],
    "rating": "8.6",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    "description": "An intimate, sweeping generational drama tracing two estranged siblings who inherit an enigmatic architectural archive hidden deep within the Nordic fjords.",
    "director": "Sofia Lindqvist",
    "cast": "Elias M\u00f8ller, Freja Lind, Henrik Vang",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "neon-nights",
    "title": "Neon Nights",
    "year": "2026",
    "duration": "1h 44m",
    "genre": "Crime",
    "categories": [
      "All",
      "Movies",
      "Action",
      "Thriller",
      "Trending"
    ],
    "rating": "8.1",
    "quality": "HD",
    "poster": "https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=800&q=80",
    "description": "An atmospheric retro-futuristic heist saga set inside the subterranean arcade districts of a sprawling metropolis.",
    "director": "Kenzo Takahashi",
    "cast": "Ryu Tanaka, Maya Lin, Alex Mercer",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "lost-kingdom",
    "title": "Lost Kingdom",
    "year": "2025",
    "duration": "2h 21m",
    "genre": "Adventure",
    "categories": [
      "All",
      "Movies",
      "Adventure",
      "Trending"
    ],
    "rating": "8.9",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=800&q=80",
    "description": "Archaeological explorers journey beyond uncharted mountain ridges into a preserved highland sanctuary that defies historical records.",
    "director": "Arthur Pendelton",
    "cast": "Claire Redgrave, Nathan Cole, Liam O'Connor",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "infinite-skies",
    "title": "Infinite Skies",
    "year": "2026",
    "duration": "1h 57m",
    "genre": "Sci-Fi",
    "categories": [
      "All",
      "Movies",
      "Sci-Fi",
      "Trending"
    ],
    "rating": "8.5",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=800&q=80",
    "description": "Atmospheric aviators patrol the upper stratosphere of a gas giant, guarding floating habitats against sudden geomagnetic storms.",
    "director": "Leonid Volkov",
    "cast": "Katia Romanova, Brian Chen, Sean Murphy",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "the-final-journey",
    "title": "The Final Journey",
    "year": "2026",
    "duration": "2h 18m",
    "genre": "Sci-Fi",
    "categories": [
      "All",
      "Movies",
      "Sci-Fi",
      "Adventure"
    ],
    "rating": "8.6",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1447433589675-4aaa569f3e05?auto=format&fit=crop&w=800&q=80",
    "description": "A veteran interstellar cartographer embarks on one final expedition across the outer ring of the Milky Way to record dying supernovas.",
    "director": "Gwen St. John",
    "cast": "Robert Sterling, Maya Hawke, Idris Kahn",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "dark-frontier",
    "title": "Dark Frontier",
    "year": "2025",
    "duration": "1h 59m",
    "genre": "Thriller",
    "categories": [
      "All",
      "Movies",
      "Thriller",
      "Action"
    ],
    "rating": "8.2",
    "quality": "HD",
    "poster": "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=800&q=80",
    "description": "Border reconnaissance agents stranded in an icy wilderness face off against an unseen adversarial squad with experimental stealth equipment.",
    "director": "Nils Holgersen",
    "cast": "Erik Bjarne, Astrid Kjaer, Tyler Ross",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "summer-memories",
    "title": "Summer Memories",
    "year": "2025",
    "duration": "1h 45m",
    "genre": "Romance",
    "categories": [
      "All",
      "Movies",
      "Romance",
      "Drama"
    ],
    "rating": "8.4",
    "quality": "HD",
    "poster": "https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=800&q=80",
    "description": "A bittersweet and luminous summer romance unfolds in a Mediterranean coastal village between a visiting botanical illustrator and a local vineyard steward.",
    "director": "Lucia Moretti",
    "cast": "Matteo Rossi, Camille Laurent, Luca Ferri",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "the-silent-code",
    "title": "The Silent Code",
    "year": "2026",
    "duration": "2h 05m",
    "genre": "Action",
    "categories": [
      "All",
      "Movies",
      "Action",
      "Thriller"
    ],
    "rating": "8.5",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
    "description": "When an impenetrable cryptography bunker goes dark, a retired intelligence specialist must decrypt an analogue signal broadcasting from deep underground.",
    "director": "Frank Castleberry",
    "cast": "Derrick Hunt, Nina Sharpe, Oliver Zhang",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "cyber-pulse",
    "title": "Cyber Pulse",
    "year": "2026",
    "duration": "1h 50m",
    "genre": "Sci-Fi",
    "categories": [
      "All",
      "Movies",
      "Sci-Fi",
      "Action"
    ],
    "rating": "8.4",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=800&q=80",
    "description": "In an interconnected cybernetic metropolis, an underground rebel syndicate races against time to disrupt a total surveillance neural grid.",
    "director": "Zane Chen",
    "cast": "Kai Rivera, Mira Vance, Aaron Paulsen",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "crimson-dawn",
    "title": "Crimson Dawn",
    "year": "2026",
    "duration": "2h 02m",
    "genre": "Thriller",
    "categories": [
      "All",
      "Movies",
      "Thriller",
      "Drama"
    ],
    "rating": "8.6",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&w=800&q=80",
    "description": "A psychological mystery surrounding an enigmatic eclipse that triggers inexplicable temporal echoes in a remote desert observatory.",
    "director": "Tara Macpherson",
    "cast": "Gabriel Ramos, Chloe Adams, Samuel Ward",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "solar-winds",
    "title": "Solar Winds",
    "year": "2025",
    "duration": "1h 55m",
    "genre": "Documentary",
    "categories": [
      "All",
      "Movies",
      "Documentary",
      "Sci-Fi"
    ],
    "rating": "9.0",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=800&q=80",
    "description": "An awe-inspiring documentary journey observing the sun's coronal ejections and our solar system's atmospheric shields through space telescope footage.",
    "director": "Dr. Evelyn Drake",
    "cast": "Narrated by Sir Anthony Harris",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "echoes-in-the-deep",
    "title": "Echoes in the Deep",
    "year": "2025",
    "duration": "2h 10m",
    "genre": "Adventure",
    "categories": [
      "All",
      "Movies",
      "Adventure",
      "Thriller"
    ],
    "rating": "8.7",
    "quality": "4K UHD",
    "poster": "https://images.unsplash.com/photo-1518709766631-a6a7f45921c3?auto=format&fit=crop&w=800&q=80",
    "description": "A deep-ocean exploration submersible descends into the Mariana Trench to investigate seismic resonances that appear mathematically deliberate.",
    "director": "Simon Bradley",
    "cast": "Laura Vance, Jonathan Miller, Scott Campbell",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  }
];

export const VIDEOS: VideoItem[] = [
  {
    "id": "v-king-dark-sea",
    "title": "The King of the Dark Sea \u2014 Official 4K Ultra HD Teaser & Full Stream",
    "duration": "24:18",
    "channel": "Movies List Masters",
    "avatar": "SA",
    "views": "890K views",
    "timeAgo": "Trending #1",
    "thumbnail": "/images/the_king_of_the_dark_sea.jpg",
    "description": "A Shimu Akter Film. 'Some bonds are not written in destiny, but in hearts...' Watch the full 4K sequence featuring the castle of the stormy seas.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v-hidden-truth",
    "title": "The Hidden Truth \u2014 Behind the Investigation & Director's Cut",
    "duration": "19:42",
    "channel": "Cinema Pulse",
    "avatar": "HT",
    "views": "720K views",
    "timeAgo": "Trending #2",
    "thumbnail": "/images/the_hidden_truth.jpg",
    "description": "A Shimu Akter Film. 'Some truths should never be found...' Rain-soaked mystery thriller breakdown and director's exclusive commentary.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v-dark-sea-king",
    "title": "The Dark Sea King \u2014 Love, Power & Destiny Full Sequence",
    "duration": "22:15",
    "channel": "FilmSphere",
    "avatar": "DK",
    "views": "640K views",
    "timeAgo": "Trending #3",
    "thumbnail": "/images/the_dark_sea_king.jpg",
    "description": "A King of the Dark Sea. A Simple Girl with a Big Heart. The legendary sword duel and moonlit galleon encounter.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v-last-promise",
    "title": "The Last Promise \u2014 Emotional Climax & Sunset Score Premiere",
    "duration": "18:35",
    "channel": "Movies List Originals",
    "avatar": "LP",
    "views": "950K views",
    "timeAgo": "Trending #4",
    "thumbnail": "/images/the_last_promise.jpg",
    "description": "A Shimu Akter Film. 'Some love stories are written by fate...' Golden hour ocean vista and unforgettable romantic embrace.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v1",
    "title": "Shimu Akter: 20-Film Cinematic Retrospective & Directorial Vision",
    "duration": "18:35",
    "channel": "Movies List Masters",
    "avatar": "SA",
    "views": "540K views",
    "timeAgo": "Just updated",
    "thumbnail": "/images/the_king_of_the_dark_sea.jpg",
    "description": "An exclusive behind-the-scenes masterclass exploring Shimu Akter's celebrated 20-film oeuvre, poetic cinematography, and the making of The Royal Heart.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v2",
    "title": "The Royal Heart: Exclusive Scene Breakdown & 4K Preview",
    "duration": "14:20",
    "channel": "Movies List Originals",
    "avatar": "SO",
    "views": "390K views",
    "timeAgo": "2 days ago",
    "thumbnail": "/images/shimu_poster_grid.jpg",
    "description": "Deep dive into the most visually breathtaking royal saga of 2026, analyzing the intricate palace set pieces and emotional orchestral score.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v3",
    "title": "Best Mystery Movies You Missed",
    "duration": "12:10",
    "channel": "Reel Insights",
    "avatar": "RI",
    "views": "185K views",
    "timeAgo": "3 days ago",
    "thumbnail": "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=800&q=80",
    "description": "Under-the-radar psychological thrillers and mystery masterpieces that kept audiences guessing until the very last frame.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v4",
    "title": "Hidden Gems Worth Watching",
    "duration": "16:30",
    "channel": "FilmSphere",
    "avatar": "FS",
    "views": "320K views",
    "timeAgo": "5 days ago",
    "thumbnail": "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    "description": "Overlooked cinematic gems that deserve a spot on your watchlist, from captivating indie dramas to visionary world cinema.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v5",
    "title": "Best Action Movies Ranked",
    "duration": "22:15",
    "channel": "Action Vault",
    "avatar": "AV",
    "views": "580K views",
    "timeAgo": "2 weeks ago",
    "thumbnail": "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=800&q=80",
    "description": "From practical stunt showcases to neon-soaked martial arts extravaganzas, we rank the most exhilarating action releases.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  },
  {
    "id": "v6",
    "title": "Upcoming Cinematic Releases & Breakdown",
    "duration": "11:50",
    "channel": "CineWave Daily",
    "avatar": "CW",
    "views": "195K views",
    "timeAgo": "4 days ago",
    "thumbnail": "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80",
    "description": "A comprehensive preview of the most anticipated movies hitting discovery platforms in the coming months.",
    "offerUrl": "https://missiondifferentyawn.com/sj9m1iqdr?key=7dd53604327a1f00a4a116d777876a57"
  }
];
