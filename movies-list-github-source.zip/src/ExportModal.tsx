import React, { useState } from 'react';
import { X, Download, CloudUpload, Github, Check, Copy, ExternalLink, HelpCircle, FileArchive } from 'lucide-react';
import { MovieTheme } from './themes.ts';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTheme: MovieTheme;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose, activeTheme }) => {
  const [copiedCmd, setCopiedCmd] = useState(false);

  if (!isOpen) return null;

  const gitCommands = `git init
git add .
git commit -m "Initial commit: Movies List Portal"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main`;

  const copyGitCommands = () => {
    navigator.clipboard.writeText(gitCommands);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[2600] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div
        className="relative w-full max-w-3xl bg-[#12151D] border border-white/15 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        style={{
          boxShadow: `0 0 50px ${activeTheme.primary}25`,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#171A22]">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-black font-bold shadow-md"
              style={{ backgroundColor: activeTheme.primary }}
            >
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Download & Deploy Packages • জিপ ফাইল ডাউনলোড ও ডিপ্লয়
              </h3>
              <p className="text-xs text-gray-400">
                Netlify ও GitHub-এ হোস্ট বা আপলোড করার জন্য তৈরি জিপ ফাইল
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white flex items-center justify-center transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Top Notice */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-500/30 flex items-start gap-3">
            <FileArchive className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <div className="text-xs text-blue-200 leading-relaxed">
              <span className="font-bold text-white">সম্পূর্ণ প্রস্তুত ২টি জিপ ফাইল:</span> একটি Netlify-তে সরাসরি ড্র্যাগ-অ্যান্ড-ড্রপ ডিপ্লয়ের জন্য প্রোডাকশন বিল্ড এবং অন্যটি GitHub রিপোজিটরিতে কোড পুশ করার জন্য সম্পূর্ণ ক্লিন সোর্স কোড।
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Netlify Package Card */}
            <div className="bg-[#171A22] border border-white/10 rounded-2xl p-5 flex flex-col justify-between hover:border-emerald-500/50 transition-colors">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                    <CloudUpload className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Ready to Deploy
                  </span>
                </div>

                <div>
                  <h4 className="text-base font-bold text-white flex items-center gap-1.5">
                    Netlify Deploy ZIP
                  </h4>
                  <p className="text-xs text-gray-400 mt-1">
                    প্রোডাকশন অপটিমাইজড স্ট্যাটিক বিল্ড (`dist` ফোল্ডার + `_redirects` + images)।
                  </p>
                </div>

                <div className="text-[11px] text-gray-400 space-y-1 font-mono bg-black/40 p-2.5 rounded-lg border border-white/5">
                  <div className="text-gray-300 font-semibold">📁 movies-list-netlify-deploy.zip</div>
                  <div>সাইজ: ~5.8 MB</div>
                  <div>ইনক্লুডেড: index.html, assets, images, _redirects</div>
                </div>

                <div className="text-xs text-gray-300 space-y-1.5 pt-1">
                  <div className="font-semibold text-white flex items-center gap-1">
                    <span>⚡ কীভাবে Netlify-তে ড্রপ করবেন:</span>
                  </div>
                  <ol className="list-decimal list-inside text-gray-400 space-y-1 text-[11px]">
                    <li>নিচের বাটনে ক্লিক করে জিপ ডাউনলোড করুন</li>
                    <li>
                      <a
                        href="https://app.netlify.com/drop"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-400 underline inline-flex items-center gap-0.5 hover:text-emerald-300"
                      >
                        <span>app.netlify.com/drop</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>{' '}
                      পেজটি খুলুন
                    </li>
                    <li>আনজিপ করা ফোল্ডারটি সেখানে Drag & Drop করুন</li>
                  </ol>
                </div>
              </div>

              <div className="pt-5">
                <a
                  href="/downloads/movies-list-netlify-deploy.zip"
                  download="movies-list-netlify-deploy.zip"
                  className="w-full py-3 px-4 rounded-xl font-bold text-xs text-[#05080E] bg-emerald-400 hover:bg-emerald-300 flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.02]"
                >
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  <span>Download Netlify ZIP (ডাউনলোড)</span>
                </a>
              </div>
            </div>

            {/* GitHub Source Code Card */}
            <div className="bg-[#171A22] border border-white/10 rounded-2xl p-5 flex flex-col justify-between hover:border-purple-500/50 transition-colors">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
                    <Github className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    Source Code
                  </span>
                </div>

                <div>
                  <h4 className="text-base font-bold text-white flex items-center gap-1.5">
                    GitHub Source Code ZIP
                  </h4>
                  <p className="text-xs text-gray-400 mt-1">
                    সম্পূর্ণ সোর্স কোড (`src`, `public`, `package.json`, `netlify.toml`, `README.md`)।
                  </p>
                </div>

                <div className="text-[11px] text-gray-400 space-y-1 font-mono bg-black/40 p-2.5 rounded-lg border border-white/5">
                  <div className="text-gray-300 font-semibold">📁 movies-list-github-source.zip</div>
                  <div>সাইজ: ~5.6 MB</div>
                  <div>ক্লিন: node_modules ও dist ব্যতিরেকে ফ্রেশ কোড</div>
                </div>

                <div className="text-xs text-gray-300 space-y-1.5 pt-1">
                  <div className="font-semibold text-white flex items-center justify-between">
                    <span>🐙 GitHub পুশ কমান্ড:</span>
                    <button
                      type="button"
                      onClick={copyGitCommands}
                      className="text-[10px] text-purple-300 hover:text-white flex items-center gap-1 bg-white/10 px-2 py-0.5 rounded transition-colors"
                    >
                      {copiedCmd ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedCmd ? 'কপি হয়েছে' : 'কপি কমান্ড'}</span>
                    </button>
                  </div>
                  <pre className="text-[10px] text-gray-400 bg-black/60 p-2 rounded border border-white/5 font-mono overflow-x-auto whitespace-pre leading-relaxed">
{`git init
git add .
git commit -m "Initial commit"
git push -u origin main`}
                  </pre>
                </div>
              </div>

              <div className="pt-5">
                <a
                  href="/downloads/movies-list-github-source.zip"
                  download="movies-list-github-source.zip"
                  className="w-full py-3 px-4 rounded-xl font-bold text-xs text-white bg-purple-600 hover:bg-purple-500 flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20 transition-all hover:scale-[1.02]"
                >
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  <span>Download GitHub Source ZIP (ডাউনলোড)</span>
                </a>
              </div>
            </div>
          </div>

          {/* Step by Step Help */}
          <div className="p-4 rounded-xl bg-[#171A22] border border-white/10 text-xs text-gray-300 space-y-2">
            <div className="font-bold text-white flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-amber-400" />
              <span>সহায়িকা (Tips):</span>
            </div>
            <p className="text-gray-400 leading-relaxed text-[11px]">
              - আপনি যদি কোনো কমান্ড ছাড়া এক ক্লিকেই ওয়েবসাইট লাইভ করতে চান, তবে <strong className="text-white">Netlify Deploy ZIP</strong> ডাউনলোড করে আনজিপ করুন এবং <a href="https://app.netlify.com/drop" target="_blank" rel="noopener noreferrer" className="text-emerald-400 underline">app.netlify.com/drop</a> এ আপলোড করলেই সাইট লাইভ হয়ে যাবে।
              <br />
              - আপনি যদি গিটহাবে কোড রাখতে চান বা ভবিষ্যতে গিটহাবে পুশ করে স্বয়ংক্রিয় ডিপ্লয় করতে চান, তবে <strong className="text-white">GitHub Source Code ZIP</strong> ব্যবহার করুন।
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#0E1118] border-t border-white/10 flex items-center justify-between text-xs text-gray-400">
          <span>Movies List • Complete Package Ready</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white font-semibold transition-colors"
          >
            Close (বন্ধ করুন)
          </button>
        </div>
      </div>
    </div>
  );
};
