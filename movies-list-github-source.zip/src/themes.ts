export interface MovieTheme {
  id: string;
  name: string;
  primary: string; // Hex e.g. #00F5D4
  primaryHover: string;
  secondary: string; // Hex e.g. #00B4D8 or #7C5CFF
  bgPrimary: string; // e.g. #08090D
  bgSecondary: string; // e.g. #101218
  bgCard: string; // e.g. #171A22
  isCustom?: boolean;
  bannerBg?: string; // Optional custom background
}

export const PRESET_THEMES: MovieTheme[] = [
  {
    id: 'cyber-neon',
    name: 'Cyber Neon (Default)',
    primary: '#00F5D4',
    primaryHover: '#33F8DC',
    secondary: '#00B4D8',
    bgPrimary: '#08090D',
    bgSecondary: '#101218',
    bgCard: '#171A22',
  },
  {
    id: 'crimson-cinema',
    name: 'Crimson Red Carpet',
    primary: '#E50914',
    primaryHover: '#FF2A38',
    secondary: '#FF4D71',
    bgPrimary: '#090709',
    bgSecondary: '#140D12',
    bgCard: '#1C131A',
  },
  {
    id: 'royal-gold',
    name: 'Royal Heritage Gold',
    primary: '#FFB703',
    primaryHover: '#FFC83B',
    secondary: '#FB8500',
    bgPrimary: '#0A0805',
    bgSecondary: '#15110A',
    bgCard: '#1E1911',
  },
  {
    id: 'emerald-matrix',
    name: 'Sci-Fi Emerald Matrix',
    primary: '#00F59B',
    primaryHover: '#38F8B1',
    secondary: '#10B981',
    bgPrimary: '#050B08',
    bgSecondary: '#0B1611',
    bgCard: '#12221B',
  },
  {
    id: 'cyberpunk-violet',
    name: 'Cyberpunk Violet',
    primary: '#A855F7',
    primaryHover: '#C084FC',
    secondary: '#EC4899',
    bgPrimary: '#090611',
    bgSecondary: '#130D23',
    bgCard: '#1B1430',
  },
  {
    id: 'solar-blaze',
    name: 'Solar Flare Orange',
    primary: '#FF5722',
    primaryHover: '#FF7043',
    secondary: '#FF9800',
    bgPrimary: '#0C0705',
    bgSecondary: '#18100C',
    bgCard: '#221712',
  },
  {
    id: 'oceanic-abyss',
    name: 'Oceanic Abyss Blue',
    primary: '#00B4D8',
    primaryHover: '#48CAE4',
    secondary: '#0077B6',
    bgPrimary: '#040810',
    bgSecondary: '#081220',
    bgCard: '#0E1C30',
  },
];
