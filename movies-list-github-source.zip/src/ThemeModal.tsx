import React, { useState } from 'react';
import { X, Palette, Plus, Check, Trash2, Sparkles, RefreshCw, Eye } from 'lucide-react';
import { MovieTheme, PRESET_THEMES } from './themes.ts';

interface ThemeModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTheme: MovieTheme;
  onSelectTheme: (theme: MovieTheme) => void;
  customThemes: MovieTheme[];
  onAddCustomTheme: (newTheme: MovieTheme) => void;
  onDeleteCustomTheme: (themeId: string) => void;
}

const BG_PRESETS = [
  { label: 'Obsidian Slate', bgPrimary: '#08090D', bgSecondary: '#101218', bgCard: '#171A22' },
  { label: 'Pitch Black', bgPrimary: '#000000', bgSecondary: '#0A0A0A', bgCard: '#141414' },
  { label: 'Deep Navy', bgPrimary: '#040810', bgSecondary: '#081220', bgCard: '#0E1C30' },
  { label: 'Cosmic Violet', bgPrimary: '#090611', bgSecondary: '#130D23', bgCard: '#1B1430' },
  { label: 'Emerald Abyss', bgPrimary: '#050B08', bgSecondary: '#0B1611', bgCard: '#12221B' },
];

const COLOR_SWATCHES = [
  '#00F5D4', '#E50914', '#FFB703', '#00F59B', '#A855F7', '#FF5722',
  '#00B4D8', '#FF3366', '#7928CA', '#F5A623', '#50E3C2', '#3B82F6'
];

export const ThemeModal: React.FC<ThemeModalProps> = ({
  isOpen,
  onClose,
  activeTheme,
  onSelectTheme,
  customThemes,
  onAddCustomTheme,
  onDeleteCustomTheme,
}) => {
  const [tab, setTab] = useState<'gallery' | 'create'>('gallery');

  // Form state for creating a new theme
  const [themeName, setThemeName] = useState('');
  const [primaryColor, setPrimaryColor] = useState('#00F5D4');
  const [secondaryColor, setSecondaryColor] = useState('#00B4D8');
  const [selectedBg, setSelectedBg] = useState(BG_PRESETS[0]);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const allThemes = [...PRESET_THEMES, ...customThemes];

  const handleCreateTheme = (e: React.FormEvent) => {
    e.preventDefault();
    if (!themeName.trim()) {
      setErrorMsg('দয়া করে থিমের একটি নাম লিখুন (Please enter a theme name)');
      return;
    }

    const newTheme: MovieTheme = {
      id: `custom-${Date.now()}`,
      name: themeName.trim(),
      primary: primaryColor,
      primaryHover: primaryColor,
      secondary: secondaryColor,
      bgPrimary: selectedBg.bgPrimary,
      bgSecondary: selectedBg.bgSecondary,
      bgCard: selectedBg.bgCard,
      isCustom: true,
    };

    onAddCustomTheme(newTheme);
    onSelectTheme(newTheme);
    setSuccessMsg(`🎉 "${newTheme.name}" থিমটি সফলভাবে যুক্ত ও প্রয়োগ করা হয়েছে!`);
    setErrorMsg('');
    setTimeout(() => {
      setSuccessMsg('');
      setTab('gallery');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[2500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div 
        className="relative w-full max-w-2xl bg-[#12151D] border border-white/15 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        style={{
          boxShadow: `0 0 50px ${activeTheme.primary}25`
        }}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#171A22]">
          <div className="flex items-center gap-3">
            <div 
              className="w-9 h-9 rounded-xl flex items-center justify-center text-black font-bold shadow-md"
              style={{ backgroundColor: activeTheme.primary }}
            >
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Movie Theme Studio • মুভি থিম ম্যানেজার
              </h3>
              <p className="text-xs text-gray-400">
                পছন্দের মুভি থিম নির্বাচন করুন অথবা নিজস্ব নতুন থিম যুক্ত করুন
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white flex items-center justify-center transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-white/10 px-6 pt-3 bg-[#12151D] gap-4">
          <button
            type="button"
            onClick={() => setTab('gallery')}
            className={`pb-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors ${
              tab === 'gallery'
                ? 'border-current text-white font-bold'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
            style={{ color: tab === 'gallery' ? activeTheme.primary : undefined }}
          >
            <Sparkles className="w-4 h-4" />
            <span>Theme Gallery (থিম তালিকা)</span>
            <span className="text-[11px] px-1.5 py-0.5 rounded-full bg-white/10 text-gray-300">
              {allThemes.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setTab('create')}
            className={`pb-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors ${
              tab === 'create'
                ? 'border-current text-white font-bold'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
            style={{ color: tab === 'create' ? activeTheme.primary : undefined }}
          >
            <Plus className="w-4 h-4" />
            <span>+ Add New Theme (নতুন থিম যুক্ত করুন)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {tab === 'gallery' ? (
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs uppercase font-extrabold tracking-wider text-gray-400">
                  Select A Theme (থিম নির্বাচন করুন)
                </span>
                <button
                  type="button"
                  onClick={() => setTab('create')}
                  className="text-xs font-bold inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 hover:bg-white/10 text-white transition-colors"
                  style={{ borderColor: `${activeTheme.primary}60` }}
                >
                  <Plus className="w-3.5 h-3.5" style={{ color: activeTheme.primary }} />
                  <span>নতুন থিম তৈরি করুন</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {allThemes.map((theme) => {
                  const isActive = activeTheme.id === theme.id;
                  return (
                    <div
                      key={theme.id}
                      onClick={() => onSelectTheme(theme)}
                      className={`group relative p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isActive
                          ? 'border-white/50 bg-[#1A1F2C] shadow-lg'
                          : 'border-white/10 bg-[#171A22] hover:border-white/25 hover:bg-[#1C202B]'
                      }`}
                      style={{
                        borderColor: isActive ? theme.primary : undefined,
                        boxShadow: isActive ? `0 0 20px ${theme.primary}30` : undefined,
                      }}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Dual Color Swatch preview */}
                        <div className="relative w-10 h-10 rounded-lg overflow-hidden shrink-0 border border-white/20 shadow-inner flex">
                          <div className="w-1/2 h-full" style={{ backgroundColor: theme.primary }} />
                          <div className="w-1/2 h-full" style={{ backgroundColor: theme.secondary }} />
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <h4 className="text-sm font-bold text-white truncate">{theme.name}</h4>
                            {theme.isCustom && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30">
                                Custom
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <span 
                              className="w-2.5 h-2.5 rounded-full inline-block" 
                              style={{ backgroundColor: theme.primary }}
                            />
                            <span className="text-[11px] text-gray-400 font-mono">
                              {theme.primary}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {isActive ? (
                          <div 
                            className="w-7 h-7 rounded-full flex items-center justify-center text-black font-black text-xs shadow-md"
                            style={{ backgroundColor: theme.primary }}
                          >
                            <Check className="w-4 h-4" />
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400 group-hover:text-white px-2 py-1 rounded bg-white/5 group-hover:bg-white/10 transition-colors">
                            Apply
                          </span>
                        )}

                        {theme.isCustom && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteCustomTheme(theme.id);
                            }}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                            title="Delete custom theme"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <form onSubmit={handleCreateTheme} className="space-y-5">
              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-semibold">
                  {errorMsg}
                </div>
              )}
              {successMsg && (
                <div className="p-3 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                  {successMsg}
                </div>
              )}

              {/* Theme Name Input */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-1.5">
                  Theme Name (থিমের নাম লিখুন) *
                </label>
                <input
                  type="text"
                  value={themeName}
                  onChange={(e) => setThemeName(e.target.value)}
                  placeholder="e.g. Dune Amber Sand, Batman Gotham, Barbie Neon..."
                  className="w-full bg-[#171A22] border border-white/15 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20 transition-all"
                  maxLength={30}
                />
              </div>

              {/* Primary & Secondary Color Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Primary Accent Color */}
                <div className="bg-[#171A22] p-4 rounded-xl border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-300 uppercase tracking-wide">
                      Primary Accent (প্রধান কালার)
                    </span>
                    <span className="text-xs font-mono text-gray-400">{primaryColor}</span>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      className="w-12 h-10 rounded-lg cursor-pointer bg-transparent border-0 p-0"
                    />
                    <input
                      type="text"
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      className="flex-1 bg-black/40 border border-white/15 rounded-lg px-3 py-1.5 text-xs text-white font-mono uppercase"
                      maxLength={7}
                    />
                  </div>

                  {/* Swatches */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {COLOR_SWATCHES.slice(0, 6).map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setPrimaryColor(c)}
                        className="w-5 h-5 rounded-full border border-white/20 hover:scale-110 transition-transform"
                        style={{ backgroundColor: c }}
                        title={c}
                      />
                    ))}
                  </div>
                </div>

                {/* Secondary Accent Color */}
                <div className="bg-[#171A22] p-4 rounded-xl border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-300 uppercase tracking-wide">
                      Gradient / Secondary (দ্বিতীয় কালার)
                    </span>
                    <span className="text-xs font-mono text-gray-400">{secondaryColor}</span>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={secondaryColor}
                      onChange={(e) => setSecondaryColor(e.target.value)}
                      className="w-12 h-10 rounded-lg cursor-pointer bg-transparent border-0 p-0"
                    />
                    <input
                      type="text"
                      value={secondaryColor}
                      onChange={(e) => setSecondaryColor(e.target.value)}
                      className="flex-1 bg-black/40 border border-white/15 rounded-lg px-3 py-1.5 text-xs text-white font-mono uppercase"
                      maxLength={7}
                    />
                  </div>

                  {/* Swatches */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {COLOR_SWATCHES.slice(6, 12).map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setSecondaryColor(c)}
                        className="w-5 h-5 rounded-full border border-white/20 hover:scale-110 transition-transform"
                        style={{ backgroundColor: c }}
                        title={c}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Background Theme Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2">
                  Background Atmosphere (ব্যাকগ্রাউন্ড মুড)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {BG_PRESETS.map((bg) => (
                    <button
                      key={bg.label}
                      type="button"
                      onClick={() => setSelectedBg(bg)}
                      className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                        selectedBg.label === bg.label
                          ? 'border-white bg-white/10'
                          : 'border-white/10 hover:border-white/20 bg-black/40'
                      }`}
                    >
                      <span 
                        className="w-4 h-4 rounded-full border border-white/30 shrink-0" 
                        style={{ backgroundColor: bg.bgPrimary }}
                      />
                      <span className="text-xs text-gray-200 font-medium truncate">{bg.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Preview Card */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300 mb-2 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5" style={{ color: primaryColor }} />
                  <span>Real-time Preview (লাইভ প্রিভিউ)</span>
                </label>
                <div 
                  className="p-5 rounded-2xl border transition-all"
                  style={{
                    backgroundColor: selectedBg.bgCard,
                    borderColor: `${primaryColor}40`,
                    boxShadow: `0 0 30px ${primaryColor}20`
                  }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span 
                      className="text-[11px] font-extrabold uppercase px-2.5 py-0.5 rounded-full border"
                      style={{
                        backgroundColor: `${primaryColor}20`,
                        borderColor: `${primaryColor}40`,
                        color: primaryColor,
                      }}
                    >
                      ★ {themeName.trim() || 'Theme Preview'}
                    </span>
                    <span 
                      className="text-[11px] font-bold px-2 py-0.5 rounded text-white"
                      style={{ backgroundColor: secondaryColor }}
                    >
                      4K ULTRA HD
                    </span>
                  </div>

                  <h4 
                    className="text-lg font-black bg-gradient-to-r bg-clip-text text-transparent mb-1"
                    style={{
                      backgroundImage: `linear-gradient(to right, ${primaryColor}, ${secondaryColor}, #FFFFFF)`
                    }}
                  >
                    Experience Cinematic Wonder
                  </h4>
                  <p className="text-xs text-gray-400 mb-4">
                    Sample card showing how buttons and highlights will render across the website.
                  </p>

                  <div className="flex gap-2">
                    <div 
                      className="px-4 py-2 rounded-xl text-xs font-extrabold text-[#05080E] shadow-lg flex items-center gap-1.5"
                      style={{
                        backgroundImage: `linear-gradient(to right, ${primaryColor}, ${secondaryColor})`,
                        boxShadow: `0 4px 14px ${primaryColor}40`
                      }}
                    >
                      <span>WATCH MAIN STREAM</span>
                    </div>
                    <div className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-white/10 border border-white/15">
                      Explore Catalog
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 px-6 rounded-xl font-extrabold text-sm text-[#05080E] shadow-xl flex items-center justify-center gap-2 transition-transform hover:-translate-y-0.5 cursor-pointer"
                  style={{
                    backgroundImage: `linear-gradient(to right, ${primaryColor}, ${secondaryColor})`,
                    boxShadow: `0 4px 20px ${primaryColor}50`
                  }}
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>Save & Apply Theme (থিম সেভ ও যুক্ত করুন)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTab('gallery')}
                  className="py-3 px-5 rounded-xl font-bold text-xs text-gray-300 bg-white/10 hover:bg-white/15 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer info note */}
        <div className="px-6 py-3 bg-[#0E1118] border-t border-white/10 flex items-center justify-between text-[11px] text-gray-400">
          <span>থিম পরিবর্তন স্বয়ংক্রিয়ভাবে ব্রাউজারে সংরক্ষিত থাকবে (Persisted in localStorage)</span>
          <button
            type="button"
            onClick={() => onSelectTheme(PRESET_THEMES[0])}
            className="text-gray-400 hover:text-white flex items-center gap-1 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset to Default</span>
          </button>
        </div>
      </div>
    </div>
  );
};
