import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  X,
  Search,
  ChevronRight,
  ChevronDown,
  Star,
  Film,
  Tv,
  CheckCircle2,
  Lock,
  Layers,
  Smartphone,
  Zap,
  Heart,
  ArrowUp,
  SlidersHorizontal,
  Sparkles,
  User,
  ShieldCheck,
  Radio,
  Clock,
  Eye,
  Maximize2,
  Palette,
  Download
} from 'lucide-react';
import { MovieTheme, PRESET_THEMES } from './themes.ts';
import { ThemeModal } from './ThemeModal.tsx';
import { ExportModal } from './ExportModal.tsx';
import {
  Movie,
  VideoItem,
  MOVIES,
  VIDEOS,
  CATEGORIES,
  POPULAR_CATEGORIES,
  FAQ_LIST,
  OFFER_LINK_1,
  OFFER_LINK_2
} from './data.ts';

function formatSeconds(totalSec: number): string {
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = Math.floor(totalSec % 60);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

export default function App() {
  // Theme state with localStorage persistence
  const [activeTheme, setActiveTheme] = useState<MovieTheme>(() => {
    try {
      const saved = localStorage.getItem('movies_list_theme');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return PRESET_THEMES[0];
  });

  const [customThemes, setCustomThemes] = useState<MovieTheme[]>(() => {
    try {
      const saved = localStorage.getItem('movies_list_custom_themes');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Sync activeTheme with document CSS variables
  useEffect(() => {
    try {
      localStorage.setItem('movies_list_theme', JSON.stringify(activeTheme));
    } catch (e) {}

    const root = document.documentElement;
    root.style.setProperty('--accent', activeTheme.primary);
    root.style.setProperty('--accent-hover', activeTheme.primaryHover || activeTheme.primary);
    root.style.setProperty('--accent-secondary', activeTheme.secondary);
    root.style.setProperty('--bg-primary', activeTheme.bgPrimary);
    root.style.setProperty('--bg-secondary', activeTheme.bgSecondary);
    root.style.setProperty('--bg-card', activeTheme.bgCard);

    const hex = activeTheme.primary.replace('#', '');
    if (hex.length === 6) {
      const r = parseInt(hex.substring(0, 2), 16);
      const g = parseInt(hex.substring(2, 4), 16);
      const b = parseInt(hex.substring(4, 6), 16);
      root.style.setProperty('--accent-rgb', `${r}, ${g}, ${b}`);
    }
  }, [activeTheme]);

  const handleAddCustomTheme = (newTheme: MovieTheme) => {
    const updated = [newTheme, ...customThemes];
    setCustomThemes(updated);
    try {
      localStorage.setItem('movies_list_custom_themes', JSON.stringify(updated));
    } catch (e) {}
  };

  const handleDeleteCustomTheme = (themeId: string) => {
    const updated = customThemes.filter((t) => t.id !== themeId);
    setCustomThemes(updated);
    try {
      localStorage.setItem('movies_list_custom_themes', JSON.stringify(updated));
    } catch (e) {}
    if (activeTheme.id === themeId) {
      setActiveTheme(PRESET_THEMES[0]);
    }
  };

  // Dynamic Theme Button and Gradient styles
  const themePrimaryGrad = `linear-gradient(135deg, ${activeTheme.primary} 0%, ${activeTheme.secondary} 100%)`;
  const primaryCtaStyle: React.CSSProperties = {
    background: themePrimaryGrad,
    color: '#05080E',
    boxShadow: `0 4px 20px ${activeTheme.primary}40`,
  };

  // Navigation & UI state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [backToTopVisible, setBackToTopVisible] = useState(false);
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(0);

  // Modals state
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);

  // Hero Preview Player Simulation
  const [heroIsPlaying, setHeroIsPlaying] = useState(false);
  const [heroPlayTime, setHeroPlayTime] = useState(1458); // 00:24:18

  // Modal Player Simulation
  const [modalIsPlaying, setModalIsPlaying] = useState(true);
  const [modalPlayTime, setModalPlayTime] = useState(1722); // 00:28:42
  const [modalMuted, setModalMuted] = useState(false);
  const [modalServer, setModalServer] = useState(1);
  const [modalBuffered] = useState(78);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const trendingSectionRef = useRef<HTMLElement>(null);

  // Scroll listener for back to top
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setBackToTopVisible(true);
      } else {
        setBackToTopVisible(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Hero player ticker
  useEffect(() => {
    let interval: any;
    if (heroIsPlaying) {
      interval = setInterval(() => {
        setHeroPlayTime((prev) => (prev >= 8640 ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [heroIsPlaying]);

  // Modal player ticker
  useEffect(() => {
    let interval: any;
    if (selectedMovie && modalIsPlaying) {
      interval = setInterval(() => {
        setModalPlayTime((prev) => (prev >= 7725 ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [selectedMovie, modalIsPlaying]);

  // Lock body scroll when modal or drawer is open
  useEffect(() => {
    if (selectedMovie || selectedVideo || mobileDrawerOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [selectedMovie, selectedVideo, mobileDrawerOpen]);

  // Keyboard shortcut: Escape closes modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedMovie(null);
        setSelectedVideo(null);
        setMobileDrawerOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filter movies by search and category
  const filteredMovies = useMemo(() => {
    return MOVIES.filter((movie) => {
      const matchesCategory =
        selectedCategory === 'All' ||
        movie.categories.some((c) => c.toLowerCase() === selectedCategory.toLowerCase()) ||
        movie.genre.toLowerCase() === selectedCategory.toLowerCase();

      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        movie.title.toLowerCase().includes(q) ||
        movie.genre.toLowerCase().includes(q) ||
        movie.year.includes(q) ||
        movie.director.toLowerCase().includes(q) ||
        movie.cast.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  // Category select with smooth scroll to trending section
  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    if (trendingSectionRef.current) {
      const yOffset = -100;
      const element = trendingSectionRef.current;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const openMovie = (movie: Movie) => {
    setSelectedMovie(movie);
    setModalIsPlaying(true);
    setModalPlayTime(1722);
  };

  const closeMovieModal = () => {
    setSelectedMovie(null);
  };

  const openVideo = (video: VideoItem) => {
    setSelectedVideo(video);
  };

  const closeVideoModal = () => {
    setSelectedVideo(null);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Find Featured Movies for specific sections
  const kingOfDarkSea = MOVIES.find((m) => m.id === 'the-king-of-the-dark-sea') || MOVIES[0];
  const hiddenTruth = MOVIES.find((m) => m.id === 'the-hidden-truth') || MOVIES[1];
  const darkSeaKing = MOVIES.find((m) => m.id === 'the-dark-sea-king') || MOVIES[2];
  const lastPromise = MOVIES.find((m) => m.id === 'the-last-promise') || MOVIES[3];
  const royalHeart = MOVIES.find((m) => m.id === 'the-royal-heart') || MOVIES[4];

  // Shimu universe 5 core highlights
  const shimuUniverseFilms = [kingOfDarkSea, hiddenTruth, darkSeaKing, lastPromise, royalHeart];

  // New releases (2026 releases)
  const newReleases = MOVIES.filter((m) => m.year === '2026').slice(5, 13);

  return (
    <div className="movies-list-app text-white min-h-screen font-sans antialiased transition-colors duration-300" style={{ backgroundColor: activeTheme.bgPrimary }}>
      {/* ==========================================================================
          HEADER & NAVIGATION
          ========================================================================== */}
      <header className="site-header fixed top-0 left-0 right-0 z-50 backdrop-blur-md border-b border-white/10 transition-colors duration-300" style={{ backgroundColor: `${activeTheme.bgPrimary}ea` }} id="siteHeader">
        <div className="container header-inner max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Brand Logo */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              scrollToTop();
            }}
            className="brand-logo flex items-center gap-3 group shrink-0"
            aria-label="Movies List Home"
          >
            <div className="brand-icon w-10 h-10 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform duration-200" style={{ background: themePrimaryGrad, boxShadow: `0 4px 18px ${activeTheme.primary}40` }}>
              <Play className="w-5 h-5 fill-[#05080E] text-[#05080E] translate-x-0.5" />
            </div>
            <span className="brand-text text-xl font-black tracking-wider bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent">
              MOVIES LIST
            </span>
          </a>

          {/* Center Search Bar */}
          <div
            className={`header-search flex-1 max-w-md mx-4 transition-all duration-200 ${
              mobileSearchOpen ? 'mobile-active flex' : 'hidden md:flex'
            }`}
            id="headerSearch"
            role="search"
          >
            <div className="search-input-wrapper relative w-full flex items-center bg-[#171A22] border border-white/10 rounded-full px-4 py-2 focus-within:border-[#00F5D4]/60 focus-within:ring-2 focus-within:ring-[#00F5D4]/20 transition-all">
              <Search className="w-4 h-4 text-gray-400 shrink-0 mr-2.5" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search movies, shows, videos..."
                className="w-full bg-transparent text-sm text-white placeholder-gray-500 focus:outline-none"
                aria-label="Search movies, shows, videos"
                autoComplete="off"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="search-clear-btn p-1 text-gray-400 hover:text-white transition-colors"
                  aria-label="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Right Navigation */}
          <div className="header-nav flex items-center gap-6">
            <nav className="nav-links hidden lg:flex items-center gap-7">
              <a href="#trendingSection" className="text-sm font-semibold text-gray-300 hover:text-white transition-colors">
                Trending
              </a>
              <a href="#featuredSection" className="text-sm font-semibold text-gray-300 hover:text-white transition-colors">
                Featured
              </a>
              <a href="#categoriesSection" className="text-sm font-semibold text-gray-300 hover:text-white transition-colors">
                Categories
              </a>
              <a href="#videosSection" className="text-sm font-semibold text-gray-300 hover:text-white transition-colors">
                Explore
              </a>
              <a href="#faqSection" className="text-sm font-semibold text-gray-300 hover:text-white transition-colors">
                FAQ
              </a>
            </nav>

            <div className="header-actions flex items-center gap-3">
              {/* Theme Studio Switcher & Creator Button */}
              <button
                type="button"
                onClick={() => setIsThemeModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-white text-xs font-bold transition-all hover:scale-105 shadow-sm cursor-pointer"
                style={{
                  borderColor: `${activeTheme.primary}70`,
                  backgroundColor: `${activeTheme.bgCard}cc`
                }}
                title="Change or Add Movie Theme (মুভি থিম পরিবর্তন ও যুক্ত করুন)"
              >
                <Palette className="w-3.5 h-3.5" style={{ color: activeTheme.primary }} />
                <span className="hidden sm:inline">Theme (থিম)</span>
              </button>

              {/* Deploy / Download ZIP Package Button */}
              <button
                type="button"
                onClick={() => setIsExportModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-white text-xs font-bold transition-all hover:scale-105 shadow-sm cursor-pointer bg-white/10 hover:bg-white/15"
                style={{
                  borderColor: 'rgba(255, 255, 255, 0.2)'
                }}
                title="Download Netlify & GitHub ZIP (ডাউনলোড জিপ)"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Deploy Zip (ডাউনলোড)</span>
              </button>
              {/* Mobile Search Toggle */}
              <button
                type="button"
                onClick={() => setMobileSearchOpen(!mobileSearchOpen)}
                className="md:hidden p-2 text-gray-300 hover:text-white transition-colors"
                aria-label="Toggle mobile search"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Profile Icon Button */}
              <a
                href={OFFER_LINK_2}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-profile hidden sm:flex items-center justify-center w-10 h-10 rounded-full bg-[#171A22] border border-white/10 text-gray-300 hover:text-white hover:border-[#00F5D4]/50 transition-all"
                aria-label="Sign In or User Profile"
              >
                <User className="w-4 h-4" />
              </a>

              {/* Get Started CTA */}
              <a
                href={OFFER_LINK_1}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary text-[#05080E] text-xs sm:text-sm font-bold px-5 py-2.5 rounded-full flex items-center gap-1.5 transition-all transform hover:-translate-y-0.5 whitespace-nowrap shadow-lg hover:brightness-110" style={primaryCtaStyle}
                id="headerGetStartedBtn"
              >
                <span>GET STARTED</span>
                <ChevronRight className="w-4 h-4" />
              </a>

              {/* Mobile Hamburger Toggle */}
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(true)}
                className="lg:hidden p-2 text-gray-300 hover:text-white transition-colors"
                id="mobileToggleBtn"
                aria-label="Toggle navigation menu"
              >
                <SlidersHorizontal className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* ==========================================================================
          MOBILE NAVIGATION DRAWER
          ========================================================================== */}
      <div className={`mobile-drawer ${mobileDrawerOpen ? 'open' : ''}`} id="mobileDrawer" aria-hidden={!mobileDrawerOpen}>
        <div
          className="mobile-drawer-backdrop"
          id="drawerBackdrop"
          onClick={() => setMobileDrawerOpen(false)}
        />
        <div className="mobile-drawer-panel bg-[#101218] border-l border-white/10 p-6 flex flex-col justify-between">
          <div>
            <div className="mobile-drawer-top flex items-center justify-between pb-6 border-b border-white/10">
              <a href="#" className="brand-logo flex items-center gap-2.5" aria-label="Movies List Home">
                <div className="brand-icon w-8 h-8 rounded-lg bg-gradient-to-tr from-[#00F5D4] to-purple-600 flex items-center justify-center">
                  <Play className="w-4 h-4 fill-[#05080E] text-[#05080E]" />
                </div>
                <span className="brand-text font-black tracking-wider text-white">MOVIES LIST</span>
              </a>
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(false)}
                className="modal-close-btn p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
                id="drawerCloseBtn"
                aria-label="Close navigation drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <ul className="mobile-nav-list mt-6 space-y-4">
              <li>
                <a
                  href="#trendingSection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  Trending Movies
                </a>
              </li>
              <li>
                <a
                  href="#featuredSection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  Editor's Pick
                </a>
              </li>
              <li>
                <a
                  href="#shimuUniverseSection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  Shimu Universe
                </a>
              </li>
              <li>
                <a
                  href="#newReleasesSection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  New Releases
                </a>
              </li>
              <li>
                <a
                  href="#categoriesSection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  Popular Categories
                </a>
              </li>
              <li>
                <a
                  href="#videosSection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  Video Highlights
                </a>
              </li>
              <li>
                <a
                  href="#whySection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  Why Movies List
                </a>
              </li>
              <li>
                <a
                  href="#faqSection"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="mobile-nav-link text-lg font-semibold text-gray-200 hover:text-[#00F5D4] transition-colors block"
                >
                  FAQ & Support
                </a>
              </li>
              <li className="pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    setIsThemeModalOpen(true);
                  }}
                  className="mobile-nav-link text-lg font-bold transition-colors flex items-center gap-2.5 w-full text-left"
                  style={{ color: activeTheme.primary }}
                >
                  <Palette className="w-5 h-5" />
                  <span>Movie Theme Studio (মুভি থিম)</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    setIsExportModalOpen(true);
                  }}
                  className="mobile-nav-link text-lg font-bold transition-colors flex items-center gap-2.5 w-full text-left text-emerald-400 hover:text-emerald-300"
                >
                  <Download className="w-5 h-5" />
                  <span>Deploy ZIP (Netlify & GitHub)</span>
                </button>
              </li>
            </ul>
          </div>

          <div className="mobile-drawer-bottom pt-6 border-t border-white/10 space-y-3">
            <a
              href={OFFER_LINK_1}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary w-full text-center block bg-gradient-to-r from-[#00F5D4] via-[#00D9F5] to-[#00B4D8] text-[#05080E] font-bold py-3 rounded-xl shadow-lg shadow-[#00F5D4]/30"
            >
              GET STARTED
            </a>
            <a
              href={OFFER_LINK_2}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-secondary w-full text-center block bg-[#171A22] border border-white/10 text-gray-200 font-semibold py-3 rounded-xl hover:bg-white/10"
            >
              SIGN IN
            </a>
          </div>
        </div>
      </div>

      <main className="pt-20">
        {/* ==========================================================================
            HERO SECTION (MAIN STREAM & BACKGROUND)
            ========================================================================== */}
        <section className="hero-section relative min-h-[92vh] flex items-center overflow-hidden py-16 px-4 sm:px-6 lg:px-8" id="heroSection" aria-label="Featured Showcase">
          {/* Hero Background Image */}
          <div className="hero-background absolute inset-0 z-0">
            <img
              src="/images/main_stream_bg.jpg"
              alt="Cinematic Main Stream Background - Shimu Akter Cinema Universe"
              className="hero-bg-img w-full h-full object-cover filter brightness-[0.45] scale-105 animate-pulse duration-[12000ms]"
              id="heroBgImg"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1920&q=80';
              }}
            />
            <div className="hero-overlay absolute inset-0 bg-gradient-to-t from-[#08090D] via-[#08090D]/75 to-transparent pointer-events-none" />
            <div className="absolute inset-0 bg-radial-gradient from-transparent via-[#08090D]/40 to-[#08090D] pointer-events-none" />
          </div>

          <div className="container hero-container-grid max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 relative z-10 items-center">
            {/* Left Hero Details */}
            <div className="hero-content lg:col-span-7 space-y-6">
              {/* Tag / Eyebrow */}
              <div className="hero-badge-eyebrow inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full text-xs font-bold tracking-wider border" style={{ backgroundColor: `${activeTheme.primary}18`, borderColor: `${activeTheme.primary}40`, color: activeTheme.primary }}>
                <span className="pulse-dot w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: activeTheme.primary }} />
                <span>SHIMU AKTER CINEMATIC UNIVERSE • NOW STREAMING</span>
              </div>

              {/* Headline */}
              <h1 className="hero-title text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-[1.08] text-white">
                Experience Pure Cinema.{' '}
                <span className="bg-gradient-to-r bg-clip-text text-transparent" style={{ backgroundImage: `linear-gradient(to right, ${activeTheme.primary}, ${activeTheme.secondary}, #FFB703)` }}>
                  Stream The Masterpieces.
                </span>
              </h1>

              {/* Description */}
              <p className="hero-description text-gray-300 text-base sm:text-lg max-w-2xl leading-relaxed">
                Immerse yourself in vivid romance, thrilling mysteries, and epic adventures from the acclaimed 20-film collection directed by Shimu Akter.
              </p>

              {/* Metadata */}
              <div className="hero-metadata-row flex flex-wrap items-center gap-3 text-xs font-semibold text-gray-400">
                <span className="meta-rating inline-flex items-center gap-1.5 bg-[#171A22] border border-white/10 px-3 py-1 rounded-md text-amber-400">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>9.5 Rating</span>
                </span>
                <span className="meta-dot text-gray-600">•</span>
                <span>2026 Premiere</span>
                <span className="meta-dot text-gray-600">•</span>
                <span>20 Feature Films</span>
                <span className="meta-dot text-gray-600">•</span>
                <span className="meta-badge bg-[#00F5D4]/20 text-[#00F5D4] border border-[#00F5D4]/30 px-2 py-0.5 rounded text-[11px] font-bold">
                  4K ULTRA HD
                </span>
                <span className="meta-badge bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded text-[11px] font-bold">
                  DOLBY VISION
                </span>
              </div>

              {/* Genres */}
              <div className="hero-genres flex flex-wrap gap-2 text-xs font-bold tracking-wider text-gray-300">
                <span className="genre-tag bg-[#171A22]/80 px-3 py-1 rounded-md border border-white/10">ROMANCE</span>
                <span className="genre-tag bg-[#171A22]/80 px-3 py-1 rounded-md border border-white/10">THRILLER</span>
                <span className="genre-tag bg-[#171A22]/80 px-3 py-1 rounded-md border border-white/10">ACTION</span>
                <span className="genre-tag bg-[#171A22]/80 px-3 py-1 rounded-md border border-white/10">DRAMA</span>
              </div>

              {/* CTA Buttons */}
              <div className="hero-buttons flex flex-wrap gap-4 pt-4">
                {/* Primary CTA -> OFFER LINK 1 */}
                <a
                  href={OFFER_LINK_1}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-primary btn-lg text-[#05080E] font-extrabold px-8 py-4 rounded-xl flex items-center gap-3 transition-all transform hover:-translate-y-1 hover:brightness-110" style={primaryCtaStyle}
                  id="heroWatchNowBtn"
                >
                  <Play className="w-5 h-5 fill-[#05080E] text-[#05080E]" />
                  <span>WATCH MAIN STREAM</span>
                </a>

                {/* Secondary CTA -> OFFER LINK 2 */}
                <a
                  href={OFFER_LINK_2}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-secondary btn-lg bg-[#171A22]/90 hover:bg-[#1E222D] border border-white/10 text-white font-bold px-8 py-4 rounded-xl flex items-center gap-3 transition-all"
                  id="heroExploreBtn"
                >
                  <Film className="w-5 h-5 text-gray-400" />
                  <span>EXPLORE ALL 20 FILMS</span>
                </a>
              </div>
            </div>

            {/* Right: Main Stream Interactive Preview Showcase Card */}
            <div className="hero-stream-showcase lg:col-span-5" id="heroStreamShowcase">
              <div className="stream-showcase-card bg-[#171A22]/95 border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl">
                <div className="stream-preview-media relative group aspect-video overflow-hidden">
                  <img
                    src="/images/the_king_of_the_dark_sea.jpg"
                    alt="Main Stream Preview - The King of the Dark Sea (A Shimu Akter Film)"
                    className="stream-preview-thumb w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    id="heroStreamThumb"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=800&q=80';
                    }}
                  />
                  <div className="stream-preview-overlay absolute inset-0 bg-gradient-to-t from-[#171A22] via-transparent to-black/60 pointer-events-none" />

                  {/* Top Badges */}
                  <div className="stream-preview-top-tags absolute top-4 left-4 right-4 flex justify-between items-center z-10">
                    <div className="stream-live-pill inline-flex items-center gap-1.5 bg-[#00F5D4]/90 text-white text-xs font-extrabold px-3 py-1 rounded-full backdrop-blur-md">
                      <span className="live-dot w-2 h-2 rounded-full bg-white animate-pulse" />
                      <span>MAIN STREAM</span>
                    </div>
                    <span className="stream-res-pill bg-black/70 text-amber-400 text-xs font-bold px-2.5 py-1 rounded-md backdrop-blur-md border border-amber-500/20">
                      4K UHD
                    </span>
                  </div>

                  {/* Center Interactive Play Button */}
                  <a
                    href={OFFER_LINK_1}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="stream-hero-play-trigger absolute inset-0 m-auto w-16 h-16 rounded-full bg-[#00F5D4]/90 hover:bg-[#00F5D4] text-[#05080E] flex items-center justify-center shadow-xl shadow-[#00F5D4]/50 z-20 group-hover:scale-110 transition-transform duration-300"
                    id="openMainStreamBtn"
                    aria-label="Stream The King of the Dark Sea in 4K"
                  >
                    <div className="pulse-ring absolute inset-0 rounded-full border-2 border-white/40 animate-ping" />
                    <Play className="w-7 h-7 fill-[#05080E] text-[#05080E] translate-x-0.5" />
                  </a>

                  {/* Bottom Playback Mini HUD */}
                  <div className="stream-preview-hud absolute bottom-3 left-4 right-4 z-10">
                    <div className="stream-mini-progress-track w-full h-1 bg-white/20 rounded-full overflow-hidden mb-2">
                      <div
                        className="stream-mini-progress-bar h-full rounded-full transition-all duration-300"
                        style={{ width: `${(heroPlayTime / 8640) * 100}%`, backgroundColor: activeTheme.primary }}
                      />
                    </div>
                    <div className="stream-mini-hud-meta flex justify-between items-center text-[11px] text-gray-300 font-medium">
                      <span id="heroStreamTimeMeta">{formatSeconds(heroPlayTime)} / 02:24:00</span>
                      <span className="hud-audio-tag text-[#7C5CFF] font-semibold">Dolby Atmos 5.1</span>
                    </div>
                  </div>
                </div>

                {/* Card Bottom Meta */}
                <div className="stream-preview-body p-6 space-y-4">
                  <div className="text-xs font-extrabold tracking-widest text-[#00F5D4]">A SHIMU AKTER FILM</div>
                  <h3 className="text-2xl font-black text-white">The King of the Dark Sea</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Some bonds are not written in destiny, but in hearts... An epic maritime saga of love, power, and destiny.
                  </p>

                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <a
                      href={OFFER_LINK_2}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full text-center bg-white/10 hover:bg-white/20 border border-white/15 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
                    >
                      <Play className="w-4 h-4 fill-white text-white" />
                      <span>START STREAM</span>
                    </a>
                    <a
                      href={OFFER_LINK_1}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full text-center text-[#05080E] font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-1.5 hover:brightness-110" style={primaryCtaStyle}
                    >
                      <span>4K MIRROR</span>
                      <ChevronRight className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==========================================================================
            SECTION 2: TRENDING NOW (WITH INTERACTIVE CATEGORY FILTER & LIVE SEARCH)
            ========================================================================== */}
        <section
          ref={trendingSectionRef}
          className="section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="trendingSection"
          aria-labelledby="trendingHeading"
        >
          {/* Header Row */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="section-tag text-[#00F5D4] text-xs font-extrabold tracking-widest uppercase">
                Featured Selections
              </span>
              <h2 className="section-title text-3xl sm:text-4xl font-extrabold mt-1 text-white" id="trendingHeading">
                Trending Now
              </h2>
              <p className="section-subtitle text-gray-400 text-sm mt-1">
                Popular picks and cinematic hits everyone is watching
              </p>
            </div>

            <a
              href={OFFER_LINK_2}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#00F5D4] hover:text-[#33F8DC] font-bold text-sm inline-flex items-center gap-1.5 transition-colors self-start md:self-end"
            >
              <span>Explore All Trending</span>
              <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          {/* Interactive Category Filter Pills */}
          <div className="category-filter-bar flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`category-pill px-4 py-2 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                  selectedCategory.toLowerCase() === cat.toLowerCase()
                    ? 'active text-[#05080E] font-bold shadow-lg'
                    : 'bg-[#171A22] text-gray-300 hover:text-white hover:bg-white/10 border border-white/10'
                }`}
                style={
                  selectedCategory.toLowerCase() === cat.toLowerCase()
                    ? {
                        backgroundColor: activeTheme.primary,
                        boxShadow: `0 4px 18px ${activeTheme.primary}45`
                      }
                    : undefined
                }
                aria-pressed={selectedCategory.toLowerCase() === cat.toLowerCase()}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Active Search & Filter Feedback */}
          {(searchQuery || selectedCategory !== 'All') && (
            <div className="flex items-center justify-between bg-[#171A22] border border-white/10 px-4 py-2.5 rounded-xl mb-6 text-xs text-gray-300">
              <div className="flex items-center gap-2">
                <span>Filtering by:</span>
                {selectedCategory !== 'All' && (
                  <span className="font-bold text-white bg-white/10 px-2 py-0.5 rounded">
                    Genre: {selectedCategory}
                  </span>
                )}
                {searchQuery && (
                  <span className="font-bold text-[#00F5D4] bg-[#00F5D4]/15 px-2 py-0.5 rounded">
                    Search: "{searchQuery}"
                  </span>
                )}
                <span>({filteredMovies.length} results)</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('All');
                  setSearchQuery('');
                }}
                className="text-xs text-gray-400 hover:text-white underline"
              >
                Reset filters
              </button>
            </div>
          )}

          {/* Movies Grid */}
          {filteredMovies.length === 0 ? (
            <div className="text-center py-20 bg-[#171A22]/50 border border-white/10 rounded-2xl p-8">
              <Film className="w-12 h-12 text-gray-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">No movies found</h3>
              <p className="text-gray-400 text-sm max-w-md mx-auto mb-6">
                We couldn't find any titles matching "{searchQuery}" in category "{selectedCategory}".
              </p>
              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('All');
                  setSearchQuery('');
                }}
                className="btn btn-primary px-6 py-2.5 rounded-full bg-[#00F5D4] text-[#05080E] font-bold text-sm"
              >
                Clear Search & Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredMovies.map((movie) => (
                <div
                  key={movie.id}
                  onClick={() => openMovie(movie)}
                  className="movie-card bg-[#171A22] rounded-xl overflow-hidden border border-white/10 hover:border-white/25 transition-all duration-300 group cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-[#00F5D4]/10 flex flex-col"
                  tabIndex={0}
                  role="button"
                  aria-label={`${movie.title}, ${movie.year}, ${movie.genre}, Rating ${movie.rating}`}
                >
                  <div className="relative aspect-[3/4] overflow-hidden bg-[#08090D]">
                    <img
                      src={movie.poster}
                      alt={movie.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#171A22] via-transparent to-black/40 opacity-70 group-hover:opacity-40 transition-opacity" />

                    {/* Top Badges */}
                    <div className="absolute top-2.5 left-2.5 right-2.5 flex justify-between items-center z-10">
                      <span className="bg-black/60 backdrop-blur-md px-2 py-0.5 rounded text-[11px] font-bold text-white border border-white/15">
                        {movie.year}
                      </span>
                      <span className="bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[11px] font-bold text-amber-400 flex items-center gap-1 border border-amber-500/20">
                        <Star className="w-3 h-3 fill-amber-400" />
                        {movie.rating}
                      </span>
                    </div>

                    {/* Hover Play Icon Overlay */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-20">
                      <div className="w-12 h-12 rounded-full bg-[#00F5D4] flex items-center justify-center shadow-lg shadow-[#00F5D4]/50 transform scale-75 group-hover:scale-100 transition-transform">
                        <Play className="w-5 h-5 fill-[#05080E] text-[#05080E] translate-x-0.5" />
                      </div>
                    </div>

                    {/* Bottom quality tag */}
                    <div className="absolute bottom-2 left-2.5 z-10">
                      <span className="bg-[#00F5D4]/90 text-white text-[10px] font-extrabold px-1.5 py-0.5 rounded">
                        {movie.quality}
                      </span>
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                        <span className="text-[#00F5D4] font-bold">{movie.genre}</span>
                        <span>{movie.duration}</span>
                      </div>
                      <h4 className="text-base font-bold text-white group-hover:text-[#00F5D4] transition-colors line-clamp-1">
                        {movie.title}
                      </h4>
                      <p className="text-gray-400 text-xs mt-1 line-clamp-1">
                        Dir. {movie.director}
                      </p>
                    </div>

                    <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-gray-400">
                      <span className="text-[11px]">Stream 4K</span>
                      <span className="font-semibold text-white group-hover:translate-x-1 transition-transform inline-flex items-center">
                        Watch <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ==========================================================================
            SECTION 3: EDITOR'S SIGNATURE PICK (THE HIDDEN TRUTH)
            ========================================================================== */}
        <section
          className="section featured-movie-section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="featuredSection"
          aria-labelledby="featuredHeading"
        >
          <div className="bg-gradient-to-r from-[#171A22] via-[#1A1E29] to-[#12151D] border border-white/10 rounded-3xl overflow-hidden p-6 sm:p-10 lg:p-14 relative shadow-2xl">
            {/* Ambient background light */}
            <div className="absolute -top-32 -right-32 w-96 h-96 bg-[#00F5D4]/10 rounded-full blur-3xl pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
              {/* Poster Column */}
              <div
                onClick={() => openMovie(hiddenTruth)}
                className="lg:col-span-5 relative rounded-2xl overflow-hidden shadow-2xl aspect-[3/4] cursor-pointer group"
              >
                <img
                  src="/images/the_hidden_truth.jpg"
                  alt="The Hidden Truth - A Shimu Akter Film"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=800&q=80';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 group-hover:opacity-75 transition-opacity" />

                {/* Hover Play Button */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-[#00F5D4] text-[#05080E] flex items-center justify-center shadow-xl shadow-[#00F5D4]/60 group-hover:scale-110 transition-transform">
                    <Play className="w-7 h-7 fill-[#05080E] translate-x-0.5" />
                  </div>
                </div>

                <div className="absolute top-4 left-4 bg-[#00F5D4] text-[#05080E] text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider">
                  HOT PREMIERE
                </div>
              </div>

              {/* Details Column */}
              <div className="lg:col-span-7 space-y-6">
                <div className="inline-flex items-center gap-2 bg-[#00F5D4]/20 text-[#00F5D4] border border-[#00F5D4]/30 px-3.5 py-1.5 rounded-full text-xs font-extrabold tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>EDITOR'S SIGNATURE PICK</span>
                </div>

                <h2 className="text-3xl sm:text-5xl font-black text-white leading-tight" id="featuredHeading">
                  The Hidden Truth
                </h2>

                <div className="text-[#00F5D4] text-sm font-extrabold tracking-widest uppercase">
                  DIRECTED BY SHIMU AKTER
                </div>

                <p className="text-gray-300 text-base sm:text-lg leading-relaxed">
                  "Some truths should never be found..." When an investigation unearths a web of long-buried secrets in a rain-drenched metropolis, two lovers risk everything to unveil the shocking truth.
                </p>

                {/* Specs row */}
                <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm font-semibold text-gray-400">
                  <span className="text-amber-400 font-extrabold flex items-center gap-1 bg-amber-400/10 px-2.5 py-1 rounded border border-amber-400/20">
                    <Star className="w-4 h-4 fill-amber-400" /> 9.5 Rating
                  </span>
                  <span>•</span>
                  <span>2026 Premiere</span>
                  <span>•</span>
                  <span>2h 15m</span>
                  <span>•</span>
                  <span className="text-[#00F5D4] font-bold">4K ULTRA HD</span>
                  <span>•</span>
                  <span className="text-purple-400 font-bold">DOLBY VISION</span>
                </div>

                {/* Cast */}
                <div className="text-xs text-gray-400 border-l-2 border-[#00F5D4] pl-3 py-0.5">
                  <span className="text-gray-500 uppercase tracking-wider mr-2">Starring:</span>
                  <span className="text-gray-200 font-medium">Elena Rostova, David Vance, Shimu Akter</span>
                </div>

                {/* Action buttons */}
                <div className="flex flex-wrap gap-4 pt-2">
                  <a
                    href={OFFER_LINK_2}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 text-[#05080E] font-extrabold px-8 py-4 rounded-xl transition-all transform hover:-translate-y-0.5 hover:brightness-110" style={primaryCtaStyle}
                  >
                    <Play className="w-5 h-5 fill-[#05080E]" />
                    <span>WATCH NOW</span>
                  </a>

                  <a
                    href={OFFER_LINK_1}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-[#232734] hover:bg-[#2c3242] border border-white/10 text-white font-bold px-6 py-4 rounded-xl transition-colors"
                  >
                    <span>STREAM 4K SERVER</span>
                    <ChevronRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==========================================================================
            SECTION 4: THE SHIMU AKTER 20-FILM CINEMATIC COLLECTION
            ========================================================================== */}
        <section
          className="section shimu-universe-section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="shimuUniverseSection"
          aria-labelledby="shimuUniverseHeading"
        >
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
            <span className="section-tag text-[#00F5D4] text-xs font-extrabold tracking-widest uppercase">
              Exclusive Canon
            </span>
            <h2 className="section-title text-3xl sm:text-5xl font-black text-white" id="shimuUniverseHeading">
              The Shimu Akter 20-Film Cinematic Collection
            </h2>
            <p className="section-subtitle text-gray-400 text-sm sm:text-base">
              A monumental achievement in visual poetry, grand storytelling, and emotional resonance. Stream the complete celebrated saga.
            </p>
          </div>

          {/* Masterpieces Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {/* Dark Sea King */}
            <div
              onClick={() => openMovie(darkSeaKing)}
              className="group bg-[#171A22] border border-white/10 rounded-2xl overflow-hidden hover:border-[#00F5D4]/50 transition-all duration-300 cursor-pointer shadow-xl flex flex-col"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src="/images/the_dark_sea_king.jpg"
                  alt="The Dark Sea King - Shimu Akter"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#171A22] via-transparent to-black/30" />
                <div className="absolute top-3 left-3 bg-[#00F5D4] text-[#05080E] text-[10px] font-extrabold px-2.5 py-1 rounded">
                  SWORD & SAGA
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-[#00F5D4] transition-colors">
                    The Dark Sea King
                  </h3>
                  <p className="text-gray-400 text-xs leading-relaxed mt-2">
                    A King of the Dark Sea. A Simple Girl with a Big Heart. Forbidden loyalties clash in a breathtaking tale of honor, sacrifice, and unconditional love.
                  </p>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs font-semibold text-gray-400">
                  <span className="text-amber-400">★ 9.4</span>
                  <span className="text-white group-hover:text-[#00F5D4] inline-flex items-center gap-1">
                    Play Feature <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>

            {/* The Last Promise */}
            <div
              onClick={() => openMovie(lastPromise)}
              className="group bg-[#171A22] border border-white/10 rounded-2xl overflow-hidden hover:border-[#00F5D4]/50 transition-all duration-300 cursor-pointer shadow-xl flex flex-col"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src="/images/the_last_promise.jpg"
                  alt="The Last Promise - Shimu Akter"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#171A22] via-transparent to-black/30" />
                <div className="absolute top-3 left-3 bg-purple-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded">
                  EMOTIONAL SAGA
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-[#00F5D4] transition-colors">
                    The Last Promise
                  </h3>
                  <p className="text-gray-400 text-xs leading-relaxed mt-2">
                    Some love stories are written by fate... An emotional tour de force spanning decades, testing bonds against the unyielding passage of time.
                  </p>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs font-semibold text-gray-400">
                  <span className="text-amber-400">★ 9.5</span>
                  <span className="text-white group-hover:text-[#00F5D4] inline-flex items-center gap-1">
                    Play Feature <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>

            {/* The Royal Heart */}
            <div
              onClick={() => openMovie(royalHeart)}
              className="group bg-[#171A22] border border-white/10 rounded-2xl overflow-hidden hover:border-[#00F5D4]/50 transition-all duration-300 cursor-pointer shadow-xl flex flex-col"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src="/images/the_king_of_the_dark_sea.jpg"
                  alt="The Royal Heart - Shimu Akter"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#171A22] via-transparent to-black/30" />
                <div className="absolute top-3 left-3 bg-amber-500 text-black text-[10px] font-extrabold px-2.5 py-1 rounded">
                  CROWN JEWEL
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-[#00F5D4] transition-colors">
                    The Royal Heart
                  </h3>
                  <p className="text-gray-400 text-xs leading-relaxed mt-2">
                    The crown jewel of director Shimu Akter's 20-film cinematic universe. A grand, heart-stirring romance unfolding across opulent royal halls.
                  </p>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs font-semibold text-gray-400">
                  <span className="text-amber-400">★ 9.4</span>
                  <span className="text-white group-hover:text-[#00F5D4] inline-flex items-center gap-1">
                    Play Feature <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Grand Banner Showcase */}
          <div className="relative rounded-3xl overflow-hidden border border-white/10 p-8 sm:p-12 bg-gradient-to-b from-[#171A22] to-[#101218]">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-4">
                <span className="text-xs font-extrabold text-[#00F5D4] tracking-widest uppercase">
                  DIRECTOR SPOTLIGHT
                </span>
                <h3 className="text-2xl sm:text-4xl font-black text-white">
                  "Cinema is the language of the soul in motion."
                </h3>
                <p className="text-gray-300 text-sm sm:text-base leading-relaxed">
                  Every film in the Shimu Akter universe is mastered in native 4K with custom sound engineering. Experience the full depth of high-contrast visuals, breathtaking maritime locations, and emotional character arcs.
                </p>
                <div className="pt-2 flex flex-wrap gap-4">
                  <a
                    href={OFFER_LINK_1}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-primary bg-[#00F5D4] hover:bg-[#33F8DC] text-[#05080E] font-bold px-6 py-3 rounded-xl shadow-lg shadow-[#00F5D4]/30 flex items-center gap-2"
                  >
                    <span>UNLOCK FULL 20-FILM ARCHIVE</span>
                    <ChevronRight className="w-4 h-4" />
                  </a>
                  <a
                    href={OFFER_LINK_2}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-secondary bg-white/10 hover:bg-white/20 text-white font-semibold px-6 py-3 rounded-xl"
                  >
                    VIEW RETROSPECTIVE NOTES
                  </a>
                </div>
              </div>

              <div className="lg:col-span-5 relative rounded-2xl overflow-hidden aspect-[4/3] shadow-2xl">
                <img
                  src="/images/shimu_poster_grid.jpg"
                  alt="Shimu Akter 20 Film Universe Poster Grid"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 bg-black/60 backdrop-blur-md p-3 rounded-xl border border-white/10 text-xs">
                  <span className="font-bold text-white">20 Titles • 4K Mastered • Complete Collection</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==========================================================================
            SECTION 5: NEW RELEASES SECTION
            ========================================================================== */}
        <section
          className="section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="newReleasesSection"
          aria-labelledby="newReleasesHeading"
        >
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="section-tag text-[#00F5D4] text-xs font-extrabold tracking-widest uppercase">
                Fresh From The Studio
              </span>
              <h2 className="section-title text-3xl sm:text-4xl font-extrabold mt-1 text-white" id="newReleasesHeading">
                New Releases
              </h2>
              <p className="section-subtitle text-gray-400 text-sm mt-1">
                Latest premieres added to the Movies List global catalog
              </p>
            </div>
            <a
              href={OFFER_LINK_1}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#00F5D4] hover:text-[#33F8DC] font-bold text-sm inline-flex items-center gap-1.5"
            >
              <span>See All New Additions</span>
              <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {newReleases.map((movie) => (
              <div
                key={movie.id}
                onClick={() => openMovie(movie)}
                className="movie-card bg-[#171A22] rounded-xl overflow-hidden border border-white/10 hover:border-white/25 transition-all duration-300 group cursor-pointer shadow-lg hover:shadow-2xl flex flex-col"
              >
                <div className="relative aspect-[3/4] overflow-hidden bg-[#08090D]">
                  <img
                    src={movie.poster}
                    alt={movie.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#171A22] via-transparent to-black/30" />

                  {/* Top Badges */}
                  <div className="absolute top-2.5 left-2.5 right-2.5 flex justify-between items-center z-10">
                    <span className="bg-[#00F5D4] px-2 py-0.5 rounded text-[10px] font-extrabold text-white">
                      NEW 2026
                    </span>
                    <span className="bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[11px] font-bold text-amber-400 flex items-center gap-1">
                      <Star className="w-3 h-3 fill-amber-400" />
                      {movie.rating}
                    </span>
                  </div>

                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20">
                    <div className="w-12 h-12 rounded-full bg-[#00F5D4] flex items-center justify-center shadow-lg shadow-[#00F5D4]/50">
                      <Play className="w-5 h-5 fill-[#05080E] text-[#05080E] translate-x-0.5" />
                    </div>
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                      <span className="text-[#00F5D4] font-bold">{movie.genre}</span>
                      <span>{movie.duration}</span>
                    </div>
                    <h4 className="text-base font-bold text-white group-hover:text-[#00F5D4] transition-colors line-clamp-1">
                      {movie.title}
                    </h4>
                  </div>
                  <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-gray-400">
                    <span>{movie.quality}</span>
                    <span className="text-white font-medium group-hover:translate-x-1 transition-transform inline-flex items-center">
                      Play Now <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ==========================================================================
            SECTION 6: POPULAR CATEGORIES (WITH INSTANT SCROLL & FILTER TRIGGER)
            ========================================================================== */}
        <section
          className="section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="categoriesSection"
          aria-labelledby="categoriesHeading"
        >
          <div className="mb-10">
            <span className="section-tag text-[#00F5D4] text-xs font-extrabold tracking-widest uppercase">
              Curated Collections
            </span>
            <h2 className="section-title text-3xl sm:text-4xl font-extrabold mt-1 text-white" id="categoriesHeading">
              Popular Categories
            </h2>
            <p className="section-subtitle text-gray-400 text-sm mt-1">
              Explore extensive catalogs segmented by cinematic flavor
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {POPULAR_CATEGORIES.map((cat) => (
              <div
                key={cat.name}
                onClick={() => handleCategorySelect(cat.name)}
                className="category-card group relative rounded-2xl overflow-hidden aspect-[4/3] cursor-pointer shadow-lg border border-white/10 hover:border-[#00F5D4]/50 transition-all duration-300"
                data-category={cat.name}
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 filter brightness-75 group-hover:brightness-90"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent group-hover:from-[#00F5D4]/40 transition-colors duration-500" />
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-xl font-bold text-white group-hover:translate-x-1 transition-transform">
                    {cat.name}
                  </h3>
                  <span className="text-xs text-gray-300 font-medium">{cat.count}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ==========================================================================
            SECTION 7: VIDEO HIGHLIGHTS / EXPLORE MORE
            ========================================================================== */}
        <section
          className="section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="videosSection"
          aria-labelledby="videosHeading"
        >
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="section-tag text-[#00F5D4] text-xs font-extrabold tracking-widest uppercase">
                Video Highlights & Teasers
              </span>
              <h2 className="section-title text-3xl sm:text-4xl font-extrabold mt-1 text-white" id="videosHeading">
                Explore More
              </h2>
              <p className="section-subtitle text-gray-400 text-sm mt-1">
                4K official teasers, behind-the-scenes masterclasses, and curated breakdowns
              </p>
            </div>
            <a
              href={OFFER_LINK_2}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#00F5D4] hover:text-[#33F8DC] font-bold text-sm inline-flex items-center gap-1.5"
            >
              <span>View All 10 Video Clips</span>
              <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {VIDEOS.slice(0, 6).map((video) => (
              <div
                key={video.id}
                onClick={() => openVideo(video)}
                className="group bg-[#171A22] rounded-xl overflow-hidden border border-white/10 hover:border-white/25 transition-all duration-300 cursor-pointer shadow-lg flex flex-col"
              >
                <div className="relative aspect-video overflow-hidden bg-black">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />

                  {/* Play icon overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-12 h-12 rounded-full bg-[#00F5D4] flex items-center justify-center shadow-lg shadow-[#00F5D4]/50">
                      <Play className="w-5 h-5 fill-[#05080E] text-[#05080E] translate-x-0.5" />
                    </div>
                  </div>

                  {/* Duration badge */}
                  <div className="absolute bottom-2.5 right-2.5 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded text-[11px] font-bold text-white">
                    {video.duration}
                  </div>

                  {/* Time ago */}
                  <div className="absolute top-2.5 left-2.5 bg-[#00F5D4]/80 text-white text-[10px] font-bold px-2 py-0.5 rounded backdrop-blur-md">
                    {video.timeAgo}
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#00F5D4] to-purple-600 flex items-center justify-center shrink-0 text-[11px] font-extrabold text-white">
                      {video.avatar}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white group-hover:text-[#00F5D4] transition-colors line-clamp-2 leading-snug">
                        {video.title}
                      </h4>
                      <p className="text-xs text-gray-400 mt-1">{video.channel}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-white/5">
                    <span>{video.views}</span>
                    <span className="text-gray-300 font-semibold flex items-center gap-1 group-hover:text-[#00F5D4]">
                      Watch Clip <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ==========================================================================
            SECTION 8: SUBSCRIPTION / ACCESS OFFER CTA
            ========================================================================== */}
        <section
          className="section offer-cta-section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="ctaSection"
          aria-label="Subscription and Access Offer"
        >
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#00F5D4]/90 via-[#0096C7] to-red-800 p-8 sm:p-14 text-center shadow-2xl">
            {/* Ambient light effects */}
            <div className="absolute inset-0 bg-radial-gradient from-transparent via-black/20 to-black/50 pointer-events-none" />

            <div className="relative z-10 max-w-3xl mx-auto space-y-6">
              <span className="bg-black/30 text-white border border-white/20 px-4 py-1.5 rounded-full text-xs font-extrabold uppercase tracking-widest inline-block">
                STREAM WITHOUT LIMITS
              </span>

              <h2 className="text-3xl sm:text-5xl font-black text-white leading-tight">
                Ready to Start Watching?
              </h2>

              <p className="text-white/90 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto">
                Stream thousands of movies, exclusive director cut premieres, and 4K Ultra HD entertainment with zero delays. Join millions of film lovers worldwide.
              </p>

              <div className="cta-buttons flex flex-wrap justify-center gap-4 pt-4">
                <a
                  href={OFFER_LINK_1}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-primary bg-white text-[#00F5D4] hover:bg-gray-100 font-black px-8 py-4 rounded-xl shadow-xl flex items-center gap-2 text-base transition-all transform hover:-translate-y-0.5"
                >
                  <Play className="w-5 h-5 fill-[#00F5D4]" />
                  <span>GET INSTANT ACCESS</span>
                </a>

                <a
                  href={OFFER_LINK_2}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-secondary bg-black/40 hover:bg-black/60 border border-white/20 text-white font-bold px-8 py-4 rounded-xl flex items-center gap-2 text-base transition-colors"
                >
                  <span>BROWSE FREE PREVIEWS</span>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* ==========================================================================
            SECTION 9: WHY MOVIES LIST? (PLATFORM BENEFITS)
            ========================================================================== */}
        <section
          className="section py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
          id="whySection"
          aria-labelledby="benefitsHeading"
        >
          <div className="section-header text-center max-w-2xl mx-auto mb-14 space-y-2">
            <span className="section-tag text-[#00F5D4] text-xs font-extrabold tracking-widest uppercase">
              Platform Quality
            </span>
            <h2 className="section-title text-3xl sm:text-4xl font-extrabold text-white" id="benefitsHeading">
              Why Movies List?
            </h2>
            <p className="section-subtitle text-gray-400 text-sm">
              Crafted for movie enthusiasts seeking effortless content exploration
            </p>
          </div>

          <div className="benefits-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* 1 */}
            <div className="benefit-card bg-[#171A22] border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#00F5D4]/40 transition-colors">
              <div className="benefit-icon-wrap w-12 h-12 rounded-xl bg-[#00F5D4]/15 border border-[#00F5D4]/30 flex items-center justify-center text-[#00F5D4] mb-5">
                <Star className="w-6 h-6 fill-[#00F5D4]" />
              </div>
              <h3 className="benefit-title text-xl font-bold text-white mb-2">Discover New Movies</h3>
              <p className="benefit-desc text-gray-400 text-sm leading-relaxed">
                Find fresh entertainment through curated collections and spotlighted discoveries.
              </p>
            </div>

            {/* 2 */}
            <div className="benefit-card bg-[#171A22] border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#00F5D4]/40 transition-colors">
              <div className="benefit-icon-wrap w-12 h-12 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-5">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="benefit-title text-xl font-bold text-white mb-2">Easy Discovery</h3>
              <p className="benefit-desc text-gray-400 text-sm leading-relaxed">
                Search and browse content by genre, popularity and category with zero friction.
              </p>
            </div>

            {/* 3 */}
            <div className="benefit-card bg-[#171A22] border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#00F5D4]/40 transition-colors">
              <div className="benefit-icon-wrap w-12 h-12 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-5">
                <Film className="w-6 h-6" />
              </div>
              <h3 className="benefit-title text-xl font-bold text-white mb-2">Curated Collections</h3>
              <p className="benefit-desc text-gray-400 text-sm leading-relaxed">
                Explore hand-picked entertainment themes, critical favorites, and top audience recommendations.
              </p>
            </div>

            {/* 4 */}
            <div className="benefit-card bg-[#171A22] border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#00F5D4]/40 transition-colors">
              <div className="benefit-icon-wrap w-12 h-12 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 mb-5">
                <Smartphone className="w-6 h-6" />
              </div>
              <h3 className="benefit-title text-xl font-bold text-white mb-2">Responsive Experience</h3>
              <p className="benefit-desc text-gray-400 text-sm leading-relaxed">
                Enjoy a polished experience seamlessly calibrated across desktop, tablet and mobile devices.
              </p>
            </div>

            {/* 5 */}
            <div className="benefit-card bg-[#171A22] border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#00F5D4]/40 transition-colors">
              <div className="benefit-icon-wrap w-12 h-12 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-5">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="benefit-title text-xl font-bold text-white mb-2">Fast & Simple</h3>
              <p className="benefit-desc text-gray-400 text-sm leading-relaxed">
                Quick navigation and lightweight interactions designed for lightning-fast browsing.
              </p>
            </div>

            {/* 6 */}
            <div className="benefit-card bg-[#171A22] border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#00F5D4]/40 transition-colors">
              <div className="benefit-icon-wrap w-12 h-12 rounded-xl bg-pink-500/15 border border-pink-500/30 flex items-center justify-center text-pink-400 mb-5">
                <Heart className="w-6 h-6" />
              </div>
              <h3 className="benefit-title text-xl font-bold text-white mb-2">Personalized Feel</h3>
              <p className="benefit-desc text-gray-400 text-sm leading-relaxed">
                Explore rich content and thematic categories tailored around your personal entertainment interests.
              </p>
            </div>
          </div>
        </section>

        {/* ==========================================================================
            SECTION 10: FAQ (GOT QUESTIONS? WE'VE GOT ANSWERS)
            ========================================================================== */}
        <section
          className="section py-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto"
          id="faqSection"
          aria-labelledby="faqHeading"
        >
          <div className="section-header text-center mb-12 space-y-2">
            <span className="section-tag text-[#00F5D4] text-xs font-extrabold tracking-widest uppercase">
              Frequently Asked Questions
            </span>
            <h2 className="section-title text-3xl sm:text-4xl font-extrabold text-white" id="faqHeading">
              Got Questions? We’ve Got Answers
            </h2>
            <p className="section-subtitle text-gray-400 text-sm">
              Clear and transparent information regarding Movies List and external offers
            </p>
          </div>

          <div className="faq-wrap space-y-4">
            {FAQ_LIST.map((faq, idx) => {
              const isOpen = activeFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="faq-item bg-[#171A22] border border-white/10 rounded-2xl overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => setActiveFaqIndex(isOpen ? null : idx)}
                    className="faq-question-btn w-full p-6 text-left flex items-center justify-between gap-4 font-bold text-white hover:text-[#00F5D4] transition-colors"
                    aria-expanded={isOpen}
                  >
                    <span className="text-base sm:text-lg">{faq.question}</span>
                    <span className={`faq-toggle-icon transition-transform duration-200 ${isOpen ? 'rotate-180 text-[#00F5D4]' : 'text-gray-400'}`}>
                      <ChevronDown className="w-5 h-5" />
                    </span>
                  </button>

                  {isOpen && (
                    <div className="faq-answer px-6 pb-6 text-gray-400 text-sm leading-relaxed border-t border-white/5 pt-4">
                      <p>{faq.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ==========================================================================
            SECTION 11: TRUST & TRANSPARENCY SECTION
            ========================================================================== */}
        <section className="trust-section py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto" id="trustSection" aria-label="Trust and Transparency Statement">
          <div className="trust-card-box bg-[#101218] border border-white/10 rounded-3xl p-8 sm:p-10 space-y-8">
            <div className="trust-grid grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="trust-pillar flex items-start gap-4">
                <div className="trust-icon w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="trust-pillar-title text-base font-bold text-white mb-1">Secure Browsing</h3>
                  <p className="trust-pillar-desc text-xs text-gray-400 leading-relaxed">
                    Modern encrypted connection protocols ensuring a safe discovery environment.
                  </p>
                </div>
              </div>

              <div className="trust-pillar flex items-start gap-4">
                <div className="trust-icon w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="trust-pillar-title text-base font-bold text-white mb-1">Transparent Links</h3>
                  <p className="trust-pillar-desc text-xs text-gray-400 leading-relaxed">
                    Clear communication regarding partner promotions and third-party sponsored destinations.
                  </p>
                </div>
              </div>

              <div className="trust-pillar flex items-start gap-4">
                <div className="trust-icon w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="trust-pillar-title text-base font-bold text-white mb-1">Mobile Friendly</h3>
                  <p className="trust-pillar-desc text-xs text-gray-400 leading-relaxed">
                    Engineered for lightweight, rapid loading across all contemporary handheld devices.
                  </p>
                </div>
              </div>
            </div>

            <div className="trust-statement text-center pt-6 border-t border-white/5 text-xs text-gray-500">
              <p>
                We aim to provide a clear and enjoyable entertainment discovery experience. Some promotional links may lead to independent third-party websites.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* ==========================================================================
          FOOTER
          ========================================================================== */}
      <footer className="site-footer bg-black border-t border-white/10 py-16 px-4 sm:px-6 lg:px-8 mt-12" id="siteFooter">
        <div className="container max-w-7xl mx-auto space-y-12">
          <div className="footer-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Col 1: Brand */}
            <div className="footer-brand-col lg:col-span-2 space-y-4">
              <a href="#" className="brand-logo flex items-center gap-3" aria-label="Movies List Home">
                <div className="brand-icon w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00F5D4] to-purple-600 flex items-center justify-center">
                  <Play className="w-4 h-4 fill-[#05080E] text-[#05080E]" />
                </div>
                <span className="brand-text text-xl font-black tracking-wider text-white">MOVIES LIST</span>
              </a>
              <p className="footer-tagline text-gray-400 text-sm max-w-sm leading-relaxed">
                Discover movies, videos and entertainment in one modern destination. Explore the celebrated 20-film Shimu Akter collection in 4K Ultra HD.
              </p>
            </div>

            {/* Col 2: Explore */}
            <div>
              <h4 className="footer-col-title text-sm font-extrabold uppercase tracking-wider text-white mb-4">
                Explore
              </h4>
              <ul className="footer-links space-y-2.5 text-xs text-gray-400">
                <li>
                  <a href="#trendingSection" className="hover:text-[#00F5D4] transition-colors">Movies</a>
                </li>
                <li>
                  <a href="#trendingSection" className="hover:text-[#00F5D4] transition-colors">Trending</a>
                </li>
                <li>
                  <a href="#categoriesSection" className="hover:text-[#00F5D4] transition-colors">Categories</a>
                </li>
                <li>
                  <a href="#newReleasesSection" className="hover:text-[#00F5D4] transition-colors">New Releases</a>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setIsExportModalOpen(true)}
                    className="text-emerald-400 hover:text-emerald-300 font-bold transition-colors flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Deploy ZIP (Netlify & GitHub)</span>
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3: Company */}
            <div>
              <h4 className="footer-col-title text-sm font-extrabold uppercase tracking-wider text-white mb-4">
                Company
              </h4>
              <ul className="footer-links space-y-2.5 text-xs text-gray-400">
                <li>
                  <a href="#whySection" className="hover:text-[#00F5D4] transition-colors">About</a>
                </li>
                <li>
                  <a href={OFFER_LINK_2} target="_blank" rel="noopener noreferrer" className="hover:text-[#00F5D4] transition-colors">Contact</a>
                </li>
                <li>
                  <a href="#faqSection" className="hover:text-[#00F5D4] transition-colors">FAQ</a>
                </li>
                <li>
                  <a href={OFFER_LINK_1} target="_blank" rel="noopener noreferrer" className="hover:text-[#00F5D4] transition-colors">Privacy</a>
                </li>
              </ul>
            </div>

            {/* Col 4: Legal */}
            <div>
              <h4 className="footer-col-title text-sm font-extrabold uppercase tracking-wider text-white mb-4">
                Legal
              </h4>
              <ul className="footer-links space-y-2.5 text-xs text-gray-400">
                <li>
                  <a href={OFFER_LINK_1} target="_blank" rel="noopener noreferrer" className="hover:text-[#00F5D4] transition-colors">Terms of Service</a>
                </li>
                <li>
                  <a href={OFFER_LINK_2} target="_blank" rel="noopener noreferrer" className="hover:text-[#00F5D4] transition-colors">Privacy Policy</a>
                </li>
                <li>
                  <a href={OFFER_LINK_1} target="_blank" rel="noopener noreferrer" className="hover:text-[#00F5D4] transition-colors">Cookie Policy</a>
                </li>
                <li>
                  <a href="#faqSection" className="hover:text-[#00F5D4] transition-colors">Disclaimer</a>
                </li>
              </ul>
            </div>
          </div>

          <div className="footer-bottom pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
            <p>© 2026 Movies List & Shimu Akter Cinematic Universe. All rights reserved.</p>
            <p className="footer-disclaimer-legal max-w-xl text-center sm:text-right">
              Movies List is an entertainment index and discovery catalog. Third-party trademarks, movie assets, and poster art belong to their respective copyright holders.
            </p>
          </div>
        </div>
      </footer>

      {/* ==========================================================================
          INTERACTIVE MOVIE DETAILS & STREAM PLAYER MODAL
          ========================================================================== */}
      {selectedMovie && (
        <div
          className="modal-overlay open fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          id="movieModalOverlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="modalTitle"
        >
          <div className="modal-container relative w-full max-w-4xl max-h-[92vh] bg-[#171A22] border border-white/15 rounded-2xl overflow-y-auto shadow-2xl">
            {/* Modal Close Button */}
            <button
              type="button"
              onClick={closeMovieModal}
              className="modal-close-btn absolute top-4 right-4 z-30 w-10 h-10 rounded-full bg-black/70 hover:bg-[#00F5D4] text-[#05080E] flex items-center justify-center border border-white/20 transition-all"
              id="modalCloseBtn"
              aria-label="Close details modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Banner Image & Interactive Stream HUD */}
            <div className="modal-banner relative w-full aspect-video max-h-96 overflow-hidden bg-black" id="modalBannerPlayer">
              <img
                src={selectedMovie.poster}
                alt={selectedMovie.title}
                id="modalImg"
                className="modal-banner-img w-full h-full object-cover filter brightness-90"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                }}
              />
              <div className="modal-banner-overlay absolute inset-0 bg-gradient-to-t from-[#171A22] via-black/40 to-black/70 pointer-events-none" />

              {/* Live Player Simulation HUD */}
              <div className="modal-player-hud absolute inset-0 flex flex-col justify-between p-4 z-20">
                {/* Top Bar */}
                <div className="modal-player-top-bar flex justify-between items-center pr-12">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setModalServer(modalServer === 1 ? 2 : 1)}
                      className="player-live-badge inline-flex items-center gap-1.5 px-3 py-1 bg-[#00F5D4] text-[#05080E] text-[11px] font-extrabold rounded-full cursor-pointer hover:bg-[#0096C7] transition-colors"
                    >
                      <span className="player-dot w-2 h-2 rounded-full bg-white animate-pulse" />
                      <span>STREAM SERVER {modalServer} (ACTIVE)</span>
                    </button>
                  </div>
                  <span className="player-quality-badge px-2.5 py-1 bg-black/70 border border-white/20 rounded text-[11px] font-bold text-white" id="modalPlayerQuality">
                    4K ULTRA HD • 60 FPS
                  </span>
                </div>

                {/* Center Big Play button -> Launches Full Stream */}
                <a
                  href={selectedMovie?.offerUrl || OFFER_LINK_1}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="modal-player-center-play self-center w-16 h-16 rounded-full bg-[#00F5D4]/90 hover:bg-[#00F5D4] text-[#05080E] flex items-center justify-center cursor-pointer shadow-2xl shadow-[#00F5D4]/70 hover:scale-110 transition-transform"
                  id="modalPlayerCenterBtn"
                  aria-label="Stream Movie in 4K"
                >
                  <Play className="w-8 h-8 fill-[#05080E] translate-x-0.5" />
                </a>

                {/* Bottom Controls */}
                <div className="modal-player-bottom-controls bg-gradient-to-t from-black/95 via-black/70 to-transparent p-3 rounded-lg space-y-2">
                  {/* Scrubber */}
                  <div
                    className="player-scrubber-wrap relative w-full h-1.5 bg-white/25 rounded-full cursor-pointer overflow-hidden hover:h-2 transition-all"
                    id="modalPlayerScrubber"
                    onClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const clickX = e.clientX - rect.left;
                      const percent = Math.max(0, Math.min(1, clickX / rect.width));
                      setModalPlayTime(Math.floor(percent * 7725));
                    }}
                  >
                    <div className="player-scrubber-buffered absolute top-0 left-0 h-full bg-white/40" style={{ width: `${modalBuffered}%` }} />
                    <div
                      className="player-scrubber-progress absolute top-0 left-0 h-full bg-[#00F5D4] shadow-[0_0_10px_#00F5D4]"
                      id="modalPlayerProgress"
                      style={{ width: `${(modalPlayTime / 7725) * 100}%` }}
                    />
                  </div>

                  {/* Buttons Row */}
                  <div className="player-controls-row flex justify-between items-center text-xs">
                    <div className="player-controls-left flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setModalIsPlaying(!modalIsPlaying)}
                        className="player-ctrl-btn text-white hover:text-[#00F5D4] transition-colors p-1"
                        id="modalPlayPauseBtn"
                        aria-label="Play or Pause"
                      >
                        {modalIsPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                      </button>
                      <span className="player-time-display font-semibold text-gray-200" id="modalPlayerTime">
                        {formatSeconds(modalPlayTime)} / {selectedMovie.duration}:00
                      </span>
                    </div>

                    <div className="player-controls-right flex items-center gap-3">
                      <span className="player-audio-indicator text-purple-400 font-bold hidden sm:inline">
                        Dolby Vision & Atmos
                      </span>
                      <button
                        type="button"
                        onClick={() => setModalMuted(!modalMuted)}
                        className="player-ctrl-btn text-white hover:text-[#00F5D4] p-1 transition-colors"
                        id="modalPlayerVolumeBtn"
                        aria-label="Audio Volume"
                      >
                        {modalMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Body Info */}
            <div className="modal-body p-6 sm:p-8 space-y-6">
              <div className="modal-header-info space-y-2">
                <div className="modal-director-badge text-xs font-extrabold tracking-widest text-[#00F5D4] uppercase" id="modalDirectorBadge">
                  {selectedMovie.director === 'Shimu Akter' ? 'A SHIMU AKTER FILM' : `DIRECTED BY ${selectedMovie.director.toUpperCase()}`}
                </div>
                <h3 className="modal-movie-title text-2xl sm:text-4xl font-black text-white" id="modalTitle">
                  {selectedMovie.title}
                </h3>
                <div className="modal-metadata flex flex-wrap items-center gap-3 text-xs sm:text-sm text-gray-400" id="modalMeta">
                  <span className="modal-rating-badge inline-flex items-center gap-1 text-amber-400 font-bold bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    {selectedMovie.rating}
                  </span>
                  <span>•</span>
                  <span>{selectedMovie.year}</span>
                  <span>•</span>
                  <span>{selectedMovie.duration}</span>
                  <span>•</span>
                  <span className="text-[#00F5D4] font-bold">{selectedMovie.genre}</span>
                  <span>•</span>
                  <span className="bg-[#00F5D4]/20 text-[#00F5D4] px-2 py-0.5 rounded text-xs font-bold">
                    {selectedMovie.quality}
                  </span>
                </div>
              </div>

              <p className="modal-description text-gray-300 text-sm sm:text-base leading-relaxed" id="modalDesc">
                {selectedMovie.description}
              </p>

              {/* Credits */}
              <div className="modal-credits grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 border-t border-b border-white/10 text-xs sm:text-sm">
                <div>
                  <div className="credit-label text-gray-500 uppercase tracking-wider text-[11px] mb-1">Director</div>
                  <div className="credit-value text-white font-semibold" id="modalDirector">
                    {selectedMovie.director}
                  </div>
                </div>
                <div>
                  <div className="credit-label text-gray-500 uppercase tracking-wider text-[11px] mb-1">Starring Cast</div>
                  <div className="credit-value text-white font-semibold" id="modalCast">
                    {selectedMovie.cast}
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="modal-action-bar space-y-4">
                <div className="modal-cta-buttons grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* CTA connected to OFFER_LINK_2: Movie Modal "CONTINUE TO WATCH" */}
                  <a
                    href={OFFER_LINK_2}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-primary btn-lg bg-gradient-to-r from-[#00F5D4] via-[#00D9F5] to-[#00B4D8] hover:from-[#33F8DC] hover:to-[#22D3EE] text-[#05080E] font-black py-4 px-6 rounded-xl shadow-xl shadow-[#00F5D4]/30 flex items-center justify-center gap-2 text-center"
                    id="modalWatchBtn"
                  >
                    <Play className="w-5 h-5 fill-[#05080E]" />
                    <span>CONTINUE TO WATCH</span>
                  </a>

                  {/* High Quality Stream Mirror -> OFFER LINK 1 */}
                  <a
                    href={OFFER_LINK_1}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-secondary btn-lg bg-[#232734] hover:bg-[#2c3242] border border-white/10 text-white font-bold py-4 px-6 rounded-xl flex items-center justify-center gap-2 text-center"
                    id="modalMirrorBtn"
                  >
                    <span>STREAM IN 4K UHD</span>
                  </a>
                </div>

                <p className="modal-disclaimer-note text-xs text-gray-500 text-center leading-relaxed">
                  Redirects to sponsor streaming destination. Full streaming access, subtitle options, and HD playback depend on sponsor server.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================================
          VIDEO HIGHLIGHT CLIP MODAL
          ========================================================================== */}
      {selectedVideo && (
        <div
          className="modal-overlay open fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
        >
          <div className="modal-container relative w-full max-w-3xl bg-[#171A22] border border-white/15 rounded-2xl overflow-hidden shadow-2xl">
            <button
              type="button"
              onClick={closeVideoModal}
              className="modal-close-btn absolute top-4 right-4 z-30 w-10 h-10 rounded-full bg-black/70 hover:bg-[#00F5D4] text-[#05080E] flex items-center justify-center border border-white/20 transition-all"
              aria-label="Close clip modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative aspect-video bg-black overflow-hidden">
              <img
                src={selectedVideo.thumbnail}
                alt={selectedVideo.title}
                className="w-full h-full object-cover filter brightness-90"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/images/the_king_of_the_dark_sea.jpg';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#171A22] via-transparent to-black/60" />
              <div className="absolute inset-0 flex items-center justify-center">
                <a
                  href={selectedVideo.offerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-16 h-16 rounded-full bg-[#00F5D4] flex items-center justify-center text-white shadow-xl shadow-[#00F5D4]/50 hover:scale-110 transition-transform"
                >
                  <Play className="w-7 h-7 fill-[#05080E] translate-x-0.5" />
                </a>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between text-xs text-gray-400">
                <span className="bg-[#00F5D4]/20 text-[#00F5D4] font-bold px-2 py-0.5 rounded">
                  {selectedVideo.timeAgo}
                </span>
                <span>{selectedVideo.duration} • {selectedVideo.views}</span>
              </div>

              <h3 className="text-xl font-bold text-white">{selectedVideo.title}</h3>
              <p className="text-gray-300 text-sm leading-relaxed">{selectedVideo.description}</p>

              <div className="pt-2">
                <a
                  href={selectedVideo.offerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full text-center block text-[#05080E] font-bold py-3.5 rounded-xl transition-all hover:brightness-110" style={primaryCtaStyle}
                >
                  CONTINUE TO FULL STREAM
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================================
          FLOATING QUICK THEME STUDIO TRIGGER
          ========================================================================== */}
      <button
        type="button"
        onClick={() => setIsThemeModalOpen(true)}
        className="fixed bottom-6 left-6 z-40 flex items-center gap-2 px-3.5 py-2.5 rounded-full border text-white shadow-2xl backdrop-blur-md transition-all transform hover:scale-105 cursor-pointer group"
        style={{
          backgroundColor: `${activeTheme.bgCard}f0`,
          borderColor: `${activeTheme.primary}80`,
          boxShadow: `0 4px 25px ${activeTheme.primary}35`,
        }}
        title="Change or Add Movie Theme (মুভি থিম পরিবর্তন ও যুক্ত করুন)"
      >
        <div
          className="w-3.5 h-3.5 rounded-full animate-pulse shadow-sm"
          style={{ backgroundColor: activeTheme.primary }}
        />
        <Palette className="w-4 h-4 text-white" />
        <span className="text-xs font-bold hidden sm:inline">Theme Studio (মুভি থিম)</span>
      </button>

      {/* ==========================================================================
          THEME STUDIO MODAL (ADD & CHANGE MOVIE THEMES)
          ========================================================================== */}
      <ThemeModal
        isOpen={isThemeModalOpen}
        onClose={() => setIsThemeModalOpen(false)}
        activeTheme={activeTheme}
        onSelectTheme={setActiveTheme}
        customThemes={customThemes}
        onAddCustomTheme={handleAddCustomTheme}
        onDeleteCustomTheme={handleDeleteCustomTheme}
      />

      {/* ==========================================================================
          EXPORT & DEPLOY MODAL (NETLIFY & GITHUB ZIP DOWNLOADS)
          ========================================================================== */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        activeTheme={activeTheme}
      />

      {/* ==========================================================================
          FLOATING BACK TO TOP BUTTON
          ========================================================================== */}
      <button
        type="button"
        onClick={scrollToTop}
        className={`back-to-top fixed bottom-6 right-6 z-40 w-12 h-12 rounded-full bg-[#232734] border border-white/20 text-white flex items-center justify-center shadow-2xl transition-all duration-300 hover:bg-[#00F5D4] hover:border-[#00F5D4] ${
          backToTopVisible ? 'visible opacity-100 translate-y-0' : 'invisible opacity-0 translate-y-4'
        }`}
        id="backToTopBtn"
        aria-label="Back to top"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </div>
  );
}
